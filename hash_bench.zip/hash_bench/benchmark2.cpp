#include <string>
#include <chrono>
#include <unordered_map>
#include "tsl/robin_map.h"
#include "ska/flat_hash_map.hpp"
#include "martin/robin_hood.h"
#include "emhash/hash_table6.hpp"
#include "emhash/hash_table5.hpp"
#include "emhash/hash_table7.hpp"
#include "phmap/phmap.h"

using my_clock = std::chrono::high_resolution_clock;


template<typename Map>
void bench(char const* title)
{
    int trials = 100;
    size_t result = 0;

    Map map;

    // Insert
    auto start = my_clock::now();
    {
        for (int i = 0; i < 10; ++i) {
            map.clear();
            for (int32_t i = 0; i < 1000000; i++)
            {
                map.emplace(i, "h");
            }
        }
    }
    result += map.size();
    double t_insert = std::chrono::duration_cast<std::chrono::duration<double>>(my_clock::now() - start).count();

    // Iter
    start = my_clock::now();
    {
        for (size_t i = 0; i < trials; ++i) {
            for (auto const& keyVal : map)
            {
                result += keyVal.second.size();
            }
        }
    }
    double t_iter = std::chrono::duration_cast<std::chrono::duration<double>>(my_clock::now() - start).count();

    // Find
    start = my_clock::now();
    {
        for (size_t x = 0; x < 10; ++x) {
            for (int32_t i = 0; i < 5000000; i++) {
                auto it = map.find(i);
                if (it != map.end())
                {
                    result += it->second.size();
                }
            }
        }
    }
    double t_find = std::chrono::duration_cast<std::chrono::duration<double>>(my_clock::now() - start).count();
    printf("%6.2f insert %6.2f iter %6.2f find %lld result: %s\n", t_insert, t_iter, t_find, result, title);
}

int main()
{
//    bench<robin_hood::unordered_node_map<int, std::string>>("robin_hood::unordered_node_map<int, std::string>");
    bench<robin_hood::unordered_flat_map<int, std::string>>("robin_hood::unordered_flat_map");
//    bench<emhash2::HashMap<int, std::string>>("emhash2::hashMap");
    bench<emhash5::HashMap<int, std::string>>("emhash5::hashMap");
    bench<emhash6::HashMap<int, std::string>>("emhash6::hashMap");
    bench<tsl::robin_map<int, std::string>>("tsl::robin_map");
    bench<emhash7::HashMap<int, std::string>>("emhash7::hashMap");
    bench<phmap::flat_hash_map<int, std::string>>("phmap::hpmap");
    bench<ska::flat_hash_map<int, std::string>>("ska::flat_map");
//    bench<std::unordered_map<int, std::string>>("std::unordered_map");

    srand(time(0));

    //phmap::flat_hash_map<int, std::string> mmap;
    robin_hood::unordered_node_map<int, std::string> mmap;
    //tsl::robin_map<int, std::string> mmap;
    //ska::flat_hash_map<int, std::string> mmap;

    for (int i = 0; i < 10000; i ++)
        mmap[rand()] = mmap[rand()];

    return 0;
}
