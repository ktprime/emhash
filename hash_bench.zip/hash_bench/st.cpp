#include <random>
#include <ctime>
#include <cassert>
#include <string>
#include <algorithm>

using namespace std;

#include "emhash/hash_table5.hpp"


#if __cplusplus >= 199711LL
    #define _C14_HASH   1
    #include "./tsl/robin_map.h"        //https://github.com/tessil/robin-map
    #include "./martin/robin_hood.h"       //https://github.com/martin/robin-hood-hashing/blob/master/src/include/robin_hood.h

    #include "./ska/flat_hash_map.hpp"  //https://github.com/skarupke/flat_hash_map/blob/master/flat_hash_map.hpp
    #include "./ska/bytell_hash_map.hpp"//https://github.com/skarupke/flat_hash_map/blob/master/bytell_hash_map.hpp
#endif

#ifndef _WIN32
    #include <signal.h>
    #include <unistd.h>
    #include <sys/resource.h>
#endif

static long long now2ms()
{
#if _WIN32 && 0
    FILETIME ptime[4] = { 0 };
    GetThreadTimes(GetCurrentThread(), &ptime[0], &ptime[1], &ptime[2], &ptime[3]);
    return (ptime[2].dwLowDateTime + ptime[3].dwLowDateTime) / 10000;
#elif 0 //__linux__ || __unix__
    struct rusage rup;
    getrusage(RUSAGE_SELF, &rup);
    long sec = rup.ru_utime.tv_sec + rup.ru_stime.tv_sec;
    long usec = rup.ru_utime.tv_usec + rup.ru_stime.tv_usec;
    return sec * 1000000 + usec;
#elif _WIN32
    return clock();
#else
    return clock() / 1000;
#endif
}

static const std::array<char, 62> ALPHANUMERIC_CHARS = {
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
};

static const std::int64_t SEED = 0;
static std::mt19937_64 generator(SEED);
std::uniform_int_distribution<std::size_t> rd_uniform(0, ALPHANUMERIC_CHARS.size() - 1);

static std::string get_random_alphanum_string(std::size_t size) {
    std::string str(size, '\0');
    for(std::size_t i = 0; i < size; i++) {
        str[i] = ALPHANUMERIC_CHARS[rd_uniform(generator)];
    }

    return str;
}

struct string_point
{
    string_point(std::string& ps)
    {
        _ps = static_cast<string*>(&ps);
#if 0
        hash = std::hash<std::string>()(ps);
#else
        hash = 0;
        for (int i = 0; i < (int)ps.size(); i++)
            hash = hash * 131 + ps[i];
#endif
    }

    bool operator == (const string_point& sp) const
    {
        return hash == sp.hash && *(sp._ps) == *_ps;
    }

    std::string *_ps;
    size_t hash;
};

struct string_hash
{
    size_t operator ()(const string_point & s) const
    {
        return s.hash;
    }
};

static void rand_string(std::vector<string>& rankdata, int size)
{
    rankdata.reserve(size);
    for (int i = 0; i < size; i++)
        rankdata.emplace_back(get_random_alphanum_string(rand() % 3 + 6));
}

int main(int argc, char* argv[])
{
	srand(time(0));

	int n1 = 300'0000;
	int n2 = 300'0000;

	if (argc > 1)
		n1 = atoi(argv[1]);

	std::vector<std::string> v1; rand_string(v1, n1);
	std::vector<std::string> v2; rand_string(v2, n2);

	for (int i = n1 / 100; i > 0; i --)
		v2.emplace_back(v1[rand() % v1.size()]);

	{
		auto nowms = now2ms();
		emhash5::HashMap<string, int> smap(n1);
		for (auto& s : v1)
			smap.emplace(std::move(s), 1);
		printf("hash ctor time ms = %lld, map.size = %ld\n", now2ms() - nowms, smap.size());

		int ssize = 0;
		nowms = now2ms();
		for (const auto& str : v2)
		{
			if (smap.contains(str))
				ssize ++;
		}
		printf("	find time ms = %lld size = %d\n", now2ms() - nowms, ssize);
		putchar('\n');
	}

	{
		auto nowms = now2ms();
		//robin_hood::unordered_flat_map<string_point, int, string_hash> smap(n1);
		//ska::flat_hash_map<string_point, int, string_hash> smap(n1);
		//tsl::robin_map<string_point, int, string_hash> smap(n1);
		emhash5::HashMap<string_point, int, string_hash> smap(n1);
		for (auto& s : v1)
			smap.emplace(s, 1);
		printf("hash ps ctor time ms = %lld, map.size = %ld\n", now2ms() - nowms, smap.size());

		int ssize = 0;
		nowms = now2ms();
		for (auto& str : v2)
		{
			if (smap.count(str) == 1)
				ssize ++;
		}
		printf("	find time ms = %lld size = %d\n", now2ms() - nowms, ssize);
	}

	return 0;
}

