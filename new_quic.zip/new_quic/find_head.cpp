#include <windows.h>
#include <algorithm>
#include <cstdio>
#include <iostream>
#include <vector>
#include <fstream>
#include <iterator>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <map>
#include <ctime>
#include <cassert>

using namespace std;

static std::string out_path  = "e:\\chromium\\src\\out\\Default\\gen";
static std::string out_path2 = "e:\\chromium\\src\\out\\Default\\gen\\base";
static std::string base_path = "e:\\chromium\\src";
//static std::string base_path = "d:\\new_quic\\gquic";

static std::string cmake_file = "d:\\new_quic\\gquic\\CMakeLists.txt";

//static std::string find_path = "d:\\iosquictrans-master\\quic\\quiclink\\";
//static std::string find_path = "e:\\chromium\\src\\net\\third_party\\quiche\\src\\quic\\quartc\\";
//static std::string find_path = "e:\\chromium\\src\\net\\quic\\crypto";
//static std::string find_path = "d:\\new_quic\\gquic\\net\\third_party\\quiche\\src\\quic\\core\\";
//static std::string find_path = "d:\\new_quic\\gquic\\net\\third_party\\quiche\\src\\quic\\quartc\\";
static std::string find_path = "d:\\new_quic\\src\\";

static std::string copy_path  = "e:\\code_find\\gquic";
static std::string copy_path2 = "e:\\code_find\\cmake";


//TODO load from config
static std::vector< std::string > build_filter;

///src/out/android-Debug/gen/base/base_jni_headers/

static std::map <std::string, int> allInclude;

static bool fileExists(const std::string& cpp_file)
{
    DWORD dwAttrib = GetFileAttributes(cpp_file.c_str());
    return (dwAttrib != INVALID_FILE_ATTRIBUTES &&    !(dwAttrib & FILE_ATTRIBUTE_DIRECTORY));
}

static bool filter_include(const std::string& cpp_file, bool isDir = false)
{
    if (cpp_file.find(".c") == string::npos && cpp_file.find(".h") == string::npos)
        return false;
    else if (cpp_file.find("fuchsia") != string::npos)
        return false;

#if NO_TEST == 0
    else if (cpp_file.find("_test") != string::npos)
        return false;
    else if (cpp_file.find("mock") != string::npos)
        return false;
//    else if (cpp_file.find("android") != string::npos)
//        return false;
//    else if (cpp_file.find("_mac") != string::npos)
//        return false;
#endif

    return true;
}

static map<int,int> parent_id;

static bool addToFilelist(int pid, string& fileName, std::vector<std::string>& fileList)
{
    if (allInclude.count(fileName) == 0 && fileExists(base_path + "\\" + fileName)) {
        parent_id[fileList.size()] = pid;
        allInclude[fileName] ++;
        fileList.emplace_back(base_path + "\\" + fileName);
        return true;
    }

    return false;
}

static bool parse_include(int pid, std::vector<std::string>& fileList)
{
    const std::string& cpp_file = fileList[pid];
    FILE* fp = fopen(cpp_file.c_str(), "r");
    if (!fp) {
        static int index = 1;
        int ppid = parent_id[pid];
        printf("%d can not find file %d %s:", index++, pid, cpp_file.c_str());

        for (auto& s : build_filter) {
            if (cpp_file.find(s)) {
                printf(" but find in build_filter ->\n");
                return true;
            }
        }

        printf("\n");
        while (ppid != 0) {
            printf("    %s\n", fileList[ppid].c_str());
            if (parent_id.count(ppid) > 0)
                ppid = parent_id[ppid];
            else
                break;
        }
        printf("\n");
        return false;
    }

    int line = 1;
    char text[1024*1];
    constexpr int warn_line = 160;
    while (fgets(text, sizeof(text), fp))
    {
        if (line++ > warn_line + 200) {
            break;
        }

        char* pin = strstr(text, "include");
        if (!pin || (text[0] == '/' && text[1] == '/'))
            continue;

        char* ps = strchr(pin + 8, '\"');
        if (!ps)
            continue;

        char* pe = strchr(ps + 3, '\"');
        if (!pe)
            continue;

        //repalce a/c to a\c
        for (int i = 1; ps [i] != '"'; i++) {
            if (ps[i] == '/')
                ps[i] = '\\';
        }

        std::string fileName = std::string(ps + 1, pe);
#if 0
        if ("zconf.h" == fileName || fileName == "utils.h") {
            // fileName = base_path + "\\third_party\\zlib\\" + fileName;
            //  continue;
            //printf("%s\n", fileName.c_str());
        }
#endif

        if (allInclude.count(fileName) > 0 || !filter_include(fileName, false)) {
            continue;
        }

        string file_full = base_path + "\\" + fileName;
        allInclude[fileName] ++;
        parent_id[fileList.size()] = pid;

        if (!fileExists(file_full)) {
            if (fileExists(out_path + "\\" + fileName)) {
                file_full = out_path + "\\" + fileName;
            }
#if 0
            else if (fileExists(out_path2 + "\\" + fileName)) {
                file_full = out_path2 + "\\" + fileName;
            }
#endif
            else {
                //printf("  from %s ---> %s\n", cpp_file.c_str(), file_full.c_str());
                const auto& pname   = cpp_file;
                auto old_path = pname.find_last_of('\\');
                auto new_name = fileName.find_last_of('\\');
                if (old_path != string::npos) {
                    auto file_full2 = pname.substr(0, old_path) + (new_name != string::npos ? fileName.substr(new_name) : "\\" + fileName);
                    if (fileExists(file_full2)) {
                        file_full = file_full2;
#if 0
                        allInclude.erase(fileName);
                        file_full2 = file_full2.substr(base_path.size() + 1);
                        allInclude[file_full2] ++;
#endif
                    }
                }
            }
        }

        fileList.emplace_back(file_full);
        if (line++ > warn_line) {
            printf("warn_line = %d %s\n", line, file_full.c_str());
        }

        if (fileName.find(".h") != string::npos) {
            //.c
            fileName.back() = 'c';//.c
            if (!addToFilelist(pid, fileName, fileList))
            {
                //.cc
                fileName += 'c';
                if (!addToFilelist(pid, fileName, fileList))
                {
                    fileName.back() = 'p';//.c
                    fileName += 'p';
                    addToFilelist(pid, fileName, fileList);//.cpp
                }
            }
        }
    }

    fclose(fp);
    return true;
}

static void find_src(const char* lpPath, std::vector<std::string> &fileList)
{
    char szFind[MAX_PATH];
    WIN32_FIND_DATA FindFileData;
    strcpy(szFind, lpPath); strcat(szFind,"\\*.*");

    HANDLE hFind=::FindFirstFile(szFind,&FindFileData);
    if (INVALID_HANDLE_VALUE == hFind)
        return;
    while(true)
    {
        char szFile[MAX_PATH];
        if (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
            if(FindFileData.cFileName[0] != '.' && !strstr(FindFileData.cFileName, "test"))
            {
                snprintf(szFile, MAX_PATH, "%s\\%s", lpPath, (char*)(FindFileData.cFileName));
                find_src(szFile, fileList);
            }
        }
        else if (filter_include(FindFileData.cFileName, false))
        {
            snprintf(szFile, MAX_PATH, "%s\\%s", lpPath, (char*)(FindFileData.cFileName));
            //std::cout << FindFileData.cFileName << std::endl;
            fileList.push_back(szFile);
        }
        if(!FindNextFile(hFind, &FindFileData))
            break;
    }
    FindClose(hFind);
}

static void find_include(std::vector<std::string>& fileList)
{
//    std::unordered_set<std::string> parsed_files;
    for (int i = 0; i < fileList.size(); i++) {
        parse_include(i, fileList);
    }
}

static void createDirectoryRecursively(const std::string& path)
{
    size_t pos = 0;
    do
    {
        pos = path.find_first_of("\\", pos + 1);
        if (pos == std::string::npos)
            break;
        CreateDirectory(path.substr(0, pos).c_str(), NULL);
    } while (true);
}

static void copyFile(const std::string& full_name, const std::string& copy_path)
{
    auto newFileName = copy_path + full_name.substr(base_path.size());
    if (!CopyFileA(full_name.c_str(), newFileName.c_str(), false)) {
        auto dwAttrs = GetFileAttributes(full_name.c_str());
        if (dwAttrs == INVALID_FILE_ATTRIBUTES)
            return;
//        dwAttrs = GetFileAttributes(newFileName.c_str());
//        if (dwAttrs == INVALID_FILE_ATTRIBUTES)
//            return;
        //create folder
        auto dir = newFileName.find_last_of("\\");
        createDirectoryRecursively(newFileName.substr(0, dir+1));
    }
}

static void parseCMake(const std::string& cmake, std::vector<std::string>& cmakeList)
{
   FILE* fp = fopen(cmake.c_str(), "r");
    if (!fp) {
        printf("can not open %s\n", cmake.c_str());
        return ;
    }

    int lines = 0;
    cmakeList.reserve(1000);
    char text[1024*16];
    while (fgets(text, sizeof(text), fp))
    {
        lines++;
        char* pin = strstr(text, ".cc");
        if (!pin)
            continue;

        char* ps = text;
        //repalce a/c to a\c
        while (*ps == ' ' || *ps == '\t')
            ps ++;

        char fc = *ps;
        if (true == ((fc >= 'a' && fc >= 'z') || (fc >= 'A' && fc <= 'Z')))
            continue;

        for (int i = 1; ps [i] != pin[0]; i++) {
            if (ps[i] == '/')
                ps[i] = '\\';
        }

        std::string fileName = std::string(ps, pin + 3);
        cmakeList.emplace_back(base_path + "\\" + fileName);
    }

    printf("cmakeList file size = %d\n", cmakeList.size());
}

int main(int argc, char* argv[])
{
    std::vector<std::string> fileList;
    fileList.reserve(100000);

    auto nows = time(0);

	//load filter
    find_src(out_path.c_str(), build_filter);

    find_src(find_path.c_str(), fileList);
    std::sort(fileList.begin(), fileList.end());

    for (int i = 0; i < fileList.size(); i++) {
        allInclude[fileList[i].substr(base_path.size() + 1)] = 1;
//        cout << fileList[i].substr(base_path.size() + 1) << endl;
    }
    cout << "total src file:" << fileList.size() << endl << endl;

    find_include(fileList);
    std::sort(fileList.begin(), fileList.end());

    std::vector<std::string> cmakeList;
    parseCMake(cmake_file, cmakeList);

    if (argc > 1)
    {
        for (auto&kv : allInclude) {
//            cout << kv.first << endl;
        }
        for (auto&v : fileList) {
           if (argc == 2)
                cout << v << endl;
            else
                copyFile(v, copy_path);
        }

        for (auto&v : cmakeList) {
           if (argc == 2)
                cout << v << endl;
            else
                copyFile(v, copy_path2);
        }
    }

    cout << "\ntotal filesize:" << fileList.size();
    cout << ", time use = " << time(0) - nows << endl;
    if (fileList.size() != allInclude.size())
        cout << "error !!!! total includes:" << allInclude.size() << endl;

    Sleep(1000 * 10);
    return 0;
}
/*
sudo perf record -e cpu-clock -g -p 17793
sudo perf script -i perf.data &> perf.unfold
sudo ./stackcollapse-perf.pl perf.unfold &> perf.folded
sudo ./flamegraph.pl perf.folded > perf.svg
sz -bye perf.svg
***/
