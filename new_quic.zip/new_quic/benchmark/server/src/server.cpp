#include <thread>

#include <assert.h>
#include <atomic>
#include <string>
#include <unordered_map>

#ifndef _WIN32
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/time.h>
#elif USE_CERT
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "Shlwapi.lib")
#pragma comment(lib, "Dbghelp.lib")
#pragma comment(lib, "Version.lib")
#pragma comment(lib, "wbemuuid.lib")
#pragma comment(lib, "delayimp.lib")
#else
#include <WinSock2.h>
#pragma comment(lib, "WS2_32.lib")
#pragma comment(lib, "Winmm.lib")
#endif

//#include "clock.h"
#include "io_service.h"
#include "qconfig.h"

#if CPU_PROFILER
#include "../../profiler.h"
#endif

using namespace quic_sdk;
using namespace quic_sdk::simple;

static int64_t rand_close = 0;
static int64_t g_tps{0}, g_qps{ 0 };
static int64_t g_rtt{0}, g_bytes{0};

static std::atomic_long gconns{ 0 };
static uint64_t g_close = 0;
static bool dup_socket = false;

struct common_head
{
    int32_t id;
    int32_t pack;
    int64_t ss; //server send time
    int64_t cs; //client send time
    int64_t size = 0;
};
constexpr int common_head_size = sizeof(common_head) - 8;

static int64_t Now2us()
{
#if 0
    return QuicClockImpl::getInstance().NowMicroseconds();
#elif (__linux__ || __APPLE__ || __unix__)
    struct timeval start;
    gettimeofday(&start, NULL);
    return start.tv_sec * 1000000l + start.tv_usec;
#elif _WIN32
    FILETIME    file_time;
    SYSTEMTIME  system_time;
    ULARGE_INTEGER ularge;

    GetSystemTime(&system_time);
    SystemTimeToFileTime(&system_time, &file_time);
    ularge.LowPart  = file_time.dwLowDateTime;
    ularge.HighPart = file_time.dwHighDateTime;
    return ularge.QuadPart / 10 + system_time.wMilliseconds / 1000;
#elif _WIN64
    return GetTickCount64();
#else
    return clock();
#endif
}

static std::string ws_upgrade = "HTTP/1.1 101 Switching Protocols\n"
"Connection: Upgrade\n"
"Sec - WebSocket - Accept : bYE0tuaS01oUw + vX26H97rmLdWc =\n"
"Upgrade : websocket\n\r\n\r\n";

class ServerConnection : public Connection
{
public:
    ehmap<QuicStream, common_head> stream_head_;
    char send_buffer_[1024*64];
    int hand_state_ = 0;
    int req_size_ = common_head_size;
    int rsp_size_ = 0;

    //listen
    ServerConnection(IOService* ios) : Connection(ios) {
    }
    //server
    ServerConnection(IOService* ios, QuicSocket socket) : Connection(ios, socket) {
    }

    ~ServerConnection() {
    }

public:
    Connection* NewConnection(IOService* ios, QuicSocket socket) override {
        return new ServerConnection(ios, socket);
    }

    // only called by server peer.
    //void OnAcceptSocket(Connection* connection) override {
        //hand_state_ = 1;
    //}

    void OnConnected(QuicStream stream) override {
        if (hand_state_ == 0)
            hand_state_ = 1;
    }

    const char* doWsReq(const char* data, size_t& len, int stream)
    {
        const auto tail = strstr(data, "\r\n\r\n");
        if (hand_state_ != 2 && strstr(data, "websocket") != nullptr) {
            ++gconns;
            Write(ws_upgrade.c_str(), ws_upgrade.size(), stream);
            hand_state_ = 2;
            rsp_size_ = 1;
            len -= (tail - data) + 4;
            if (0 == len)
                return nullptr;
            data = tail + 4;
        }

        assert(len >= req_size_);
        unsigned int pack = (*(unsigned int*)(&data[4]));
        req_size_ = pack >> 16;
        rsp_size_ = pack & 0xFFFF;
        if (gconns < 10)
            printf("req_size_ = %d, rsp_size_ = %d\n", req_size_, rsp_size_);
        return data;
    }

    void OnRecv(const char* data, size_t len, QuicStream stream) override {
        ++g_tps;
        g_bytes += len;

        //check data size
        if (rsp_size_ <= 1) {
            data = doWsReq(data, len, stream);
            if (!data)
                return;
        }

        const auto nowus = Now2us();
        int recv_offset = 0, send_size = 0;
        auto& head = stream_head_[stream];
        auto& hsize = head.size;
        if (hsize > 0) {
            const auto total = hsize + len;
            if (total < req_size_) {
                if (hsize < common_head_size)
                    memcpy((char*)&head + hsize, data, common_head_size - hsize);
                hsize = total;
                return;
            } else if (hsize < common_head_size) {
                memcpy((char*)&head + hsize, data, common_head_size - hsize);
            }

            const int pack4 = (req_size_ << 16) + rsp_size_;
            assert(pack4 == head.pack);
            auto& rtt = head.ss; { g_rtt += (nowus - rtt) / 1000; } rtt = nowus;
            memcpy(send_buffer_, &head, common_head_size);
            send_size = common_head_size;
            recv_offset = req_size_ - hsize;
            ++g_qps;
        }

        constexpr int max_send = sizeof(send_buffer_) - common_head_size * 2;
        while (recv_offset + req_size_ <= (int)len) {
            auto& head = *(common_head*)(data + recv_offset);
            auto& rtt     = head.ss; { g_rtt += (nowus - rtt) / 1000; } rtt = nowus;
            //assert(pack4 == head.pack);

            memcpy(send_buffer_ + send_size, &head, common_head_size);
            send_size    += common_head_size;
            recv_offset += req_size_;

            if (send_size > max_send) {
                //Write(send_buffer_, send_size, stream);
                Write(send_buffer_, send_size / common_head_size, common_head_size, rsp_size_, stream);
                send_size = 0;
            }
            ++g_qps;
        }

        //packe last
        int remain = len - recv_offset;
        if (remain > 0)
            memcpy(&head, data + recv_offset, std::min(common_head_size, remain));
        hsize = remain;

        if (send_size > 0)
            Write(send_buffer_, send_size / common_head_size, common_head_size, rsp_size_, stream);
            //Write(send_buffer_, send_size, stream);

        if (rand_close > 0 && g_close == 0 && (g_tps & rand_close) == 0) {
            g_close = Socket();
        }
    }

    void FlushBuffer(int stream, int res) override {
        g_tps -= res;;
    }

    void OnClose(int sysError, int quicError, bool closeByPeer) override {
        printf("Close Socket fd = %d sysErr=%d, quicErr=%d, closeByPeer:%d\n", Socket(), sysError, quicError, closeByPeer);
        if (hand_state_ > 0)
            gconns --;
        hand_state_ = -1;
    //    delete this;
    }

    void OnStreamClose(int sysError, int quicError, QuicStream stream) override {
        stream_head_.erase(stream);
    }
};

//const std::string&, const char*, int, const char*, const char*
static void quic_log(const char* cfile, int line, const char* func, const char* squic_log)
{
    printf("%s %s:%d %s\n", cfile, func, line, squic_log);
}

#define MULTI_THREAD  1
static std::vector<IOService*> ios_vec;
static void startThread(int id, const struct sockaddr_in& svr, int listen)
{
    auto ios = new IOService(true);
    ios_vec.push_back(ios);
    auto server = new ServerConnection(ios);
    struct sockaddr_in addr;
    memcpy(&addr, &svr, sizeof(svr));
    int tid = ios_vec.size() - 1;
    addr.sin_port = svr.sin_port;// +256 * (id - 1);

    int res = server->Bind((struct sockaddr*)&addr, sizeof(addr));
    if (res < 0) {
        printf("Server Bind error = %d\n", res);
        exit(1);
    }

    printf("=================== thread server%d:port:listen %s:%d ep = %d\n\n",
        id,inet_ntoa(addr.sin_addr), (int)htons(addr.sin_port), ios->epFd());

    if (listen > 1)
    {
        auto server2 = new ServerConnection(ios);
        struct sockaddr_in addr2;
        memcpy(&addr2, &svr, sizeof(svr));
        if (!dup_socket)
            addr2.sin_port = addr.sin_port + 256;

        int res = server2->Bind((struct sockaddr*)&addr2, sizeof(addr2));
        if (res < 0) {
            printf("Server Bind error = %d\n", res);
            exit(1);
        }
        printf("=================== thread server%d:port:listen %s:%d ep = %d\n\n",
            tid + 1, inet_ntoa(addr2.sin_addr), (int)htons(addr2.sin_port), ios->epFd());
    }

#ifdef MULTI_THREAD
    auto t = new std::thread([tid]() {

        for (;;) {
            auto ios = ios_vec[tid];
            ios->Run(1'000);

            auto socket = g_close;
            if (socket > 0) {
                std::thread closethread([=] {
                    bool ret = ios->CloseConnect(g_close);
                    DebugPrint(dbg_error, "    close ret = %d, socket = %d\n", (int)ret, (int)socket);
                });
                closethread.detach();
                g_close = 0;
            }
            if (rand() % 10000 == 0) {
                //delete ios;
                //break;
            }
        }
    });

    t->detach();
#endif
}

static const auto sleep_s = 5;
static void show(double delay)
{
    if (g_tps > 0 || gconns > 0)
    printf("TPS:%5d/sec, QPS:%7d/sec, BW:%3.2lf MB/sec, Conn:%d, rtt = %4d ms----------------------------------------\n",
            (int)(g_tps / delay), (int)(g_qps / delay), (double)(g_bytes / (1024.0 * delay * 1024)), (int)gconns, (int) (g_rtt / (g_qps + 1)));

    g_rtt   = g_qps = 0;
    g_bytes = g_tps = 0;
}

int main(int argc, char* argv[])
{
    srand(Now2us());

#ifdef _WIN32
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    printf("main server come %d\n", iResult);
#endif

#if CPU_PROFILER
    GProfiler::Initialize();
#endif

    uint64_t debug_mask = dbg_error | dbg_warn | dbg_info;
    QuicSetLogFunc(quic_log, debug_mask);
    //    debug_mask = dbg_close | dbg_ack_timeout;

    //    GProfiler::Initialize();
    printf("i p t y d n q f u b:\nip port thread bbr dbg_mask back_udp log sever_config dup_socket packet_size\n");
    printf("example: ./bserver2 i127.0.0.1 p443 t2 d14 l2 y2 g1M u n1 z2 f1 b1450\n\n");

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(6121);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    int listen = 1, threads = 1;
    for (int i = 1; i < argc; i++)
    {
        const auto cmd = argv[i][0];
        const char* arg = argv[i] + 1;
        const int avi = atoi(arg);
        if (cmd == 'i') {
            if (arg[0] == '0') {
                arg = "112.90.94.153"; addr.sin_port = htons(443);
            }
            else if (arg[0] == '3') {
                arg = "120.76.62.74"; addr.sin_port = htons(443);
            }
            else if (arg[0] == '4')
                arg = "14.116.174.178";
            addr.sin_addr.s_addr = inet_addr(arg);
        }
        else if (cmd == 't') {
            threads = avi;
            QuicSetOption("threads", threads);
        }
        else if (cmd == 'l') {
            listen = avi;
        }
        else if (cmd == 'd') {
            int mask = avi;
            if (mask == 0)
                debug_mask = 0;
            if (mask < 0)
                debug_mask = -1u;
            else if (mask < 30)
                debug_mask |= (1ul << mask);
            else
                debug_mask |= mask;
            QuicSetLogFunc(quic_log, debug_mask);
        }
        else if (cmd == 'p') {
            addr.sin_port = htons(avi);
        }
        else if (cmd == 'u')
            dup_socket = !dup_socket;
        else if (cmd == 'a')
            rand_close = (1u << avi) - 1;
        else if (cmd == 'z')
            QuicSetOption("hyc", avi);
        else if (cmd == 'b')
            QuicSetOption("packet", avi);
        else if (cmd == 'f')
            QuicSetOption("scfg", 1);
        else if (cmd == 'n')
            QuicSetOption("back_udp", avi);
        else if (cmd == 'y') {
            QuicSetBBR(avi);
            QuicSetOption("bbr", avi);
        }
    }

    //initQuic(quic_version);
    QuicSetOption("chrome_quic_log", 0);

    printf("==================== IP:port:listen = %s:%d:%d, (debug_mask = %0x use_config = %d, bbr = %d, encode = %d)\n\n",
        inet_ntoa(addr.sin_addr), (int)htons(addr.sin_port), listen, (int)debug_mask,
        (int)QuicHasOption("scfg"), (int)QuicHasOption("bbr"), (int)QuicHasOption("hyc"));

    startThread(1, addr, listen);

    {
        for (int i = 2; i <= threads; i++) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            if (!dup_socket)
                addr.sin_port += (1 << 8) * listen;
            startThread(i, addr, listen);
            //QuicBindListenEp(ios_vec[0]->epFd(), ios_vec[i - 1]->epFd());
        }
    }

    auto last_show = Now2us();
    auto next_show = last_show + sleep_s * 1000001;
    for (;;) {
#ifndef MULTI_THREAD
        if (two && ios_vec.size() == 2)
            ios_vec[1]->Run(1000);

//        assert(ios_vec[0]->epFd() == 1);
        ios_vec[0]->Run(1000);
#else
        std::this_thread::sleep_for(std::chrono::milliseconds(10'000));
#endif

        const auto nowus = Now2us();
        if (nowus > next_show) {
            const auto delay = (nowus - last_show) / 1000000.0;
            show(delay);
            last_show = nowus;
            next_show = last_show + sleep_s * 1000001;
        }
    }
    return 0;
}
