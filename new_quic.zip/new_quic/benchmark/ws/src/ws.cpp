#if __linux__ || __unix__ || __APPLE__
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <sys/time.h>
#else
    #pragma comment(lib, "WS2_32.lib")
    #pragma comment(lib, "Winmm.lib")
    #include <WinSock2.h>
#endif

#define EMH_STATIS 11
#define EMH_REHASH_LOG 11

#include "quic_socket.h"
#include "io_service.h"
#include "qconfig.h"
#include "option.h"
//#include "qclock.h"
#include "util/spinlock.h"

#include "jce/JceHelper.h"
#include "jce/wup.h"

#include "HUYA/EWebSocketCommandType.h"
#include "HUYA/WSUserInfo.h"
#include "HUYA/WSDeRegisterReq.h"
#include "HUYA/EWSDeRegisterFlag.h"
#include "HUYA/WSRegisterGroupReq.h"
#include "HUYA/WSRegisterGroupRsp.h"
#include "HUYA/WebSocketCommand.h"
#include "HUYA/WSPushMessage.h"
#include "HUYA/MessageNotice.h"

#include "HUYA/WSPushMessage_V2.h"
//#include "HUYA/WSHistoryMsgRsp.h"
#include "HUYA/WSLaunchReq.h"
#include "HUYA/WSLaunchRsp.h"

//#include "HUYA/WSHistoryMsgReq.h"
//#include "HUYA/WSHistoryMsgRsp.h"

//#include "HUYA/QueryHttpDnsReq.h"
//#include "HUYA/QueryHttpDnsRsp.h"

#include <chrono>
#include <thread>
#include <mutex>

using namespace HUYA;
using namespace quic_sdk;
using namespace quic_sdk::simple;
using namespace taf;
using namespace wup;
using namespace JceSerialize;

static vector<int64_t> lGroupIds = {
#if 0
    1394575534, 17363578, 1632563722,
    1191588902, 1067459140,
    1616443012, 1099531728404, 367138632,
    813535483,  1524418085l,
    1539218884, 1738051752, 1394575543,
    1751457687, 1271256459,
#elif 0
    367138632,813535483,2285403183,
    1632563722,1724691,1394575534,1610145122,1191588902,
    2368274334,1388474069,1423782087
#else
    813535483, 1009333046, 1610145122, 1169407747, 102556630, 60325867, 1699667589, 1191588902,
    1724691, 1703883402, 313871061, 1173538624, 2364556832, 15887954, 1272997391, 80772793, 1346609715,
    618378372, 1649138459, 157143080, 100523075, 2359671046, 1199562199022, 1259519847887, 1151982461,
    1560173861, 1504623021, 1738051752, 2383394458, 1199568522765, 2297371393, 1199567274910, 1259514594957,
    1199515480194, 1303739693, 967499203, 1430972471, 15817125, 1199514302111, 1730640958, 1199513935211, 1199514045264,
    1796000690, 60006210, 1565837254, 680710521, 12534603, 1199539171693, 1394575534, 1751457687, 1347966827, 1199561014129,
    1572204739, 1199517349201, 562409422, 3570509, 1199523015287, 1199569608961, 1394575543, 2389685578, 232444842, 961825702,
    2340128232, 1259516798850, 362894679, 86857041, 1199559652936, 1709401262, 1671329164, 1153737007,
    346656759, 1199559945934, 1199547681759, 2177840487, 1044945394, 1199558661584, 1420816766, 1674470414,
    1199547092915, 1199577538641, 1863037181, 2377236661, 2478792525, 1279530092681, 1199570683580, 307072887,
    391793659, 1199523981286, 64310431, 1199524128786, 1824554292, 2452236201, 1847969530, 631787729,
    1199541858141, 1199547236137, 1279513524046, 304582356, 1199543834680, 1199526947752, 1299518630967, 1199547095279,
    1610592543, 1199553695622, 1795363292, 2378843046, 1259521463453, 1199512806789, 2455525840, 1199538671098,
    2399113093, 1829837096, 2285522577, 1291885942, 1069843731
#endif
};

static vector<string> sGroudIds = {
    "comm:123456",
    "chat:1191588092", "live:1191588092",
};

static std::atomic<uint64_t> g_requestId(65536);
static int64_t g_qps(0), g_recv(0), g_push(0), g_nowms;
static uint32_t g_connection = {0}, g_stream = {2}, g_incr = {0};

static ehmap<int64_t, int> wsCmdSize;
static ehmap<int64_t, int> groupIdPushs;
static ehmap<int64_t, int64_t> request2Time;

static SpinLock g_spinlock;

#ifdef NO_LOCK_THREAD
#define LOCK_GUARD
#else
#define LOCK_GUARD std::lock_guard<SpinLock> lg(g_spinlock)
#endif

struct WebSocketPacket
{
    enum opcode_type
    {
        CONTINUATION = 0x0,
        TEXT_FRAME = 0x1,
        BINARY_FRAME = 0x2,
        CLOSE = 8,
        PING = 9,
        PONG = 0xa,
    };
};

static int64_t now2ms()
{
#if 0
    return QuicClockImpl::getInstance().NowMS();
#elif (__linux__ || __APPLE__ || __unix__)
    struct timeval start;
    gettimeofday(&start, NULL);
    return start.tv_sec * 1000l + start.tv_usec / 1000;
#elif _WIN32
    FILETIME    file_time;
    SYSTEMTIME  system_time;
    ULARGE_INTEGER ularge;

    GetSystemTime(&system_time);
    SystemTimeToFileTime(&system_time, &file_time);
    ularge.LowPart = file_time.dwLowDateTime;
    ularge.HighPart = file_time.dwHighDateTime;
    return ularge.QuadPart / 10000 + system_time.wMilliseconds / 1000000;
#else
    return clock();
#endif
}

static int64_t now2ms2()
{
#if 0
    return QuicClockImpl::getInstance().NowMicroseconds() / 1000;
#elif (__linux__ || __APPLE__ || __unix__)
    struct timeval start;
    gettimeofday(&start, NULL);
    return start.tv_sec * 1000l + start.tv_usec / 1000;
#elif _WIN32
    FILETIME    file_time;
    SYSTEMTIME  system_time;
    ULARGE_INTEGER ularge;

    GetSystemTime(&system_time);
    SystemTimeToFileTime(&system_time, &file_time);
    ularge.LowPart = file_time.dwLowDateTime;
    ularge.HighPart = file_time.dwHighDateTime;
    return ularge.QuadPart / 10000 + system_time.wMilliseconds / 1000000;
#else
    return clock();
#endif
}

#if 0
static string tm2str(const struct tm& stTm, const string& sFormat)
{
    char sTimeString[255];
    strftime(sTimeString, sizeof(sTimeString), sFormat.c_str(), &stTm);
    return string(sTimeString);
}

static string tm2str(const time_t &t, const string& sFormat)
{
    struct tm ttm;
#ifdef _WIN32
    localtime_s(&ttm, &t);
#else
    localtime_r(&t, &ttm);
#endif

    return tm2str(ttm, sFormat);
}

static string now2str(const string& sFormat)
{
    time_t t = time(NULL);
    return tm2str(t, sFormat);
}
#endif

static bool use_1Rtt = true;
static const std::string web_scoket_head =
            "GET / websocket / 1.1\r\nConnection: Upgrade\r\nHost: cdnws.api.huya.com : 443\r\nSec-WebSocket-Extensions: server_no_context_takeover; client_no_context_takeover\r\nSec-WebSocket-Key: 1nfFhaAuXEQ1ukqhiLDNZA == \r\nSec-WebSocket-Version: 13\r\nUpgrade: websocket\r\nUser-Agent: hysignal\r\n\r\n";

class WebSocketConnection : public Connection
{
public:
    using Connection::Connection;
    ehmap<int, std::string> recv_buf_;
    ehmap<int, int> push_stream_;
    ehmap<int, int> recv_pack_;

    std::string send_buf_;
    std::string ping_pakcet_;
    std::string server_ip_;
    WebSocketCommand ws_packet_;

    int64_t groupId_ = 0, pushMsgs_ = 0, uid_ = 0;
    uint64_t hand_time_ = now2ms2();
    int hand_state_  = 0;
    int last_stream_ = PublicStream, last_index_ = 0;

public:
    // only called by server peer.
    //void OnAcceptSocket(Connection* connection) override {}
    void OnClose(int quicError, bool bFromRemote) override {
        if (hand_state_ == 2) {
            g_connection --;
            hand_state_ = 0;
        }

        printf("  ===================  %d Close with %s by %s[quicError = %d：%s]: connections remain %d ============\n", g_incr,
            server_ip_.c_str(), bFromRemote ? "server" : "client", quicError, QuicErrorToString(quicError), (int)g_connection);
        delete this;
    }

    void OnStreamClose(int quicError, QuicStream stream) override {
        recv_buf_.erase(stream);
        recv_pack_.erase(stream);
        push_stream_.erase(stream);
    }

    void OnNewStream(QuicStream stream, bool fromPeer) override {
        recv_buf_.emplace(stream, "");
        recv_pack_.emplace(stream, 0);
        if (fromPeer) {
            push_stream_.emplace(stream, 0);
        }
    }

    // only called by client peer.
    void OnConnected(QuicStream stream) override {
        //auto connect_ms = (now2ms2() - hand_time_);
        //printf(" co[%d] quic connect time = %04d ms\n", (int)g_connection, (int)connect_ms);

        if (hand_state_ == 0)
            hand_state_ = 1;
#if 0
        //late come on
        else if (hand_state_ == 2 && send_buf_.size() != 0) {
            Write(send_buf_.c_str(), send_buf_.size(), stream);
            send_buf_.clear();
        }
#endif
        if (!use_1Rtt) {
            Write(web_scoket_head.c_str(), web_scoket_head.size(), stream);
        }
        recv_buf_.shrink_to_fit();
    }

    void FlushBuffer(int stream, int res) override {
#if 0
        auto& buffer = recv_buf_[stream];
        if (buffer.size() > 1024 * 20)
            printf("stream[%d] recv_buf remain %zd\n", stream, buffer.size());
#endif

        if (send_buf_.size() > 0) {
            auto send_steam = selectStream(stream);
            Write(send_buf_.c_str(), send_buf_.size(), send_steam); send_buf_.clear();
        }
    }

    const char* doWsRsp(const char* data, size_t& len, int stream)
    {
        const auto tail = strstr(data, "\r\n\r\n");
        if (strstr(data, "Upgrade") != nullptr && strstr(data, "websocket") != nullptr && tail != nullptr) {
            hand_state_ = 2;
            if (send_buf_.size() != 0 && Write(send_buf_.c_str(), send_buf_.size(), stream))
                send_buf_.clear();
            printf("%d ws[%d:%s] = %04d ms\n", g_incr, ++g_connection, server_ip_.c_str(), int(now2ms2() - hand_time_));
            len -= (tail - data) + 4;
            if (0 == len)
                return nullptr;
             return tail + 4;
        }
        return data;
    }

    void OnRecv(const char* data, size_t len, QuicStream stream) override {
        if (hand_state_ <= 1) {
            data = doWsRsp(data, len, stream);
            if (!data)
                return;
        }
        g_nowms = now2ms();

        last_stream_ = stream;
        auto& buffer = recv_buf_[stream];
        int& pack    = recv_pack_[stream];
        int offset = 0;

        while (0 > pack) { //fill ws head
            auto head_pack = -pack;
            if ((int)len < head_pack) {
                buffer.append(data, len);
                pack += (int)len;
                return;
            }
            offset = 0;
            buffer.append(data, head_pack);
            decodeWebSocket(buffer.data(), buffer.size(), offset, pack);
            len -= head_pack; data += head_pack;
        }

        if ((int)len < pack) { //not a full ws packet
            pack -= len;
            buffer.append(data, len);
            return;
        }
        else if (pack > 0) { //decode last packet with pack full
            buffer.append(data, pack);
            offset = pack - (int)buffer.size();
            decodeWebSocket(buffer.data(), buffer.size(), offset, pack);
            buffer.clear();
        }

        //decode continus memory
        assert(0 == pack);
        while (decodeWebSocket(data + offset, (int)(len - offset), offset, pack));
        if (len > offset)
            buffer.append(data + offset, (int)(len - offset));
        else
            pack = 0;
    }

    bool decodeWebSocket(const char* in, const int size, int& offset, int& pack)
    {
        if (size < 2) {
            pack = size - 8;
            return false;
        }

        //const unsigned char IsEOF = (in[0] & 0x80) > 0;
        //const unsigned char opCode = in[0] & 0xf;
        taf::Int64 iLength = in[1] & 0x7f;
        size_t iCurr = 2;

        if (iLength == 126)
        {
            if (size >= iCurr + 2) {
                iLength = ntohs(*(taf::UInt16*)(in + iCurr));
                iCurr += 2;
            } else {
                pack = size - iCurr - 2; return false;
            }
        }
        else if (iLength == 127)
        {
            if (size >= iCurr + 8) {
                iLength = ntohl(*(taf::Int64*)(in + iCurr));
                iCurr += 8;
            } else {
                pack = size - iCurr - 8; return false;
            }
        }

        unsigned char cMask[4] = {0};
        const bool bHasMask = (in[1] & 0x80) > 0;
        if (bHasMask && size > iCurr + 4)
        {
            memcpy(cMask, in + iCurr, 4);
            iCurr += 4;
        }

        auto packLeng = (int)(iCurr + iLength);
        if (size >= packLeng)
        {
            //WebSocketPacket tPacket;
            auto data = (char*)in + iCurr;
            if (bHasMask)
            {
                for (size_t i = 0; i < iLength; ++i)
                    data[i] = data[i] ^ cMask[i % 4];
            }

            recvMsg(data, iLength);
            offset += packLeng;
            pack = 0;
        }
        else
            pack = packLeng - size;

        return size > packLeng;
    }

    void encodeWebSocket(int iOpcode, string&& sBuffer)
    {
        send_buf_.push_back((char)(0x80 | iOpcode));
        if (sBuffer.size() < 126)
        {
            send_buf_.push_back((char)sBuffer.size());
        }
        else if (sBuffer.size() < 65536)
        {
            send_buf_.push_back((char)126);
            taf::UInt16 size = ntohs(sBuffer.size());
            send_buf_.append((char *)&size, (char *)&size + sizeof(size));
        }
        else
        {
            send_buf_.push_back((char)127);
            taf::Int64 size = htonl(sBuffer.size());
            send_buf_.append((char *)&size, (char *)&size + sizeof(size));
        }
        send_buf_.append(sBuffer.begin(), sBuffer.end());
    }

    int selectStream(int last)
    {
        auto stream_num = recv_buf_.size() - push_stream_.size();
        if (stream_num < g_stream) {
            if (last_index_ > 100)
                return CreateOutgoingStream()->StreamId();
            else if (stream_num == 0)
                return last;
        }

        uint32_t stream_index = ((uint32_t)last_index_ ++) % stream_num;
        for (auto& v : recv_buf_) {
            if (0 == push_stream_.count(v.first) && stream_index-- == 0) {
                //QuicCloseStream(v.first);
                return v.first;
            }
        }
        return last;
    }

    //http://120.76.62.74:4434
    void init(const string& sUrl, int id)
    {
        //pares url
        int port = 443;
        char ip_address[30] = { "112.90.94.153" };

        auto ppos = sUrl.find(':', 6);
        if (ppos != string::npos) {
            port = atoi(sUrl.c_str() + ppos + 1);
            auto ips = sUrl.find("//");
            if (ips == string::npos) ips = -2;
            memset(ip_address, 0, sizeof(ip_address));
            memcpy(ip_address, sUrl.c_str() + (ips + 2), ppos - (ips + 2));
        } else {
            memcpy(ip_address, sUrl.c_str(), sUrl.size());
            ip_address[sUrl.size()] = 0;
        }

        server_ip_ = ip_address;
        struct sockaddr_in addr; addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        addr.sin_addr.s_addr = inet_addr(ip_address);

        if (use_1Rtt)
            Connect((struct sockaddr*)&addr, sizeof(addr), web_scoket_head);
        else
            Connect((struct sockaddr*)&addr, sizeof(addr), "");

        g_incr ++;
        printf("%d connect to %s:%d\n", g_incr, ip_address, port);
    }

    void logout()
    {
        HUYA::WSDeRegisterReq tDeRegisterReq;
        tDeRegisterReq.iDeRegisterType = HUYA::EWSDeRegisterFlag::EWSDeRegisterFlag_UID;
        sendCmdRequest(EWSCmdC2S_DeregisterReq, Serialize(tDeRegisterReq));
    }

    void login(long uid, int64_t gindex)
    {
        uid_ = uid;
        if (gindex < 10000 || groupIdPushs.size() == 0)
            groupId_ = lGroupIds[gindex % lGroupIds.size()];
        else if (groupIdPushs.size() == 1)
            groupId_ = groupIdPushs.begin()->first;//find max
        else {
            uint32_t group_index = ((uint32_t)g_qps++) % groupIdPushs.size();
            for (auto& v : groupIdPushs) {
                if (group_index-- == 0) {
                    groupId_ = v.first;
                    break;
                }
            }
        }

        vector<string> groudIds = {
            "chat:" + std::to_string(groupId_),
            "live:" + std::to_string(groupId_),
            sGroudIds[0]
        };

        WSRegisterGroupReq tWSRegisterGroupReq;
        tWSRegisterGroupReq.vGroupId = groudIds;
        sendCmdRequest(EWSCmdC2S_RegisterGroupReq, Serialize(tWSRegisterGroupReq));
    }

    void wupCall()
    {
#if 0
        HUYA::QueryHttpDnsReq tQueryHttpDnsReq;
        tQueryHttpDnsReq.lUid = 999999;
        tQueryHttpDnsReq.sUA = "test&1.0&huashu";
        tQueryHttpDnsReq.vDomain.push_back("cdnws.api.huya.com");
        HUYA::QueryHttpDnsRsp tQueryHttpDnsRsp;

        wup::UniPacket<> up;
        up.setServantName( "launch" );
        up.setFuncName( "queryHttpDns" );
        up.put( "tReq", tQueryHttpDnsReq);
        string sBuf;
        up.encode( sBuf );
#endif

        WSLaunchReq tWSLaunchReq;
        tWSLaunchReq.lUid    = uid_;
        QuicSetSocketOpt(Socket(), quic_sdk::eQuicSocketOptionType::sockopt_conn_uid, uid_);
        tWSLaunchReq.sAppSrc = "pc_sdk&zh&2052";
        tWSLaunchReq.sUA     = "pc&1.1.2&1360";

        wup::UniPacket<> up;
        up.setServantName( "launch" );
        up.setFuncName( "wsLaunch" );
        up.put( "tReq", tWSLaunchReq);

        vector<taf::Char> sData;
        up.encode(sData);
        sendCmdRequest(EWSCmd_WupReq, std::move(sData));

#if 0
        WSHistoryMsgReq tWSHistoryMsgReq;
        tWSHistoryMsgReq.lUid = uid_;
        tWSHistoryMsgReq.vGroupId = sGroudIds;
        tWSHistoryMsgReq.lLastMsgId = rand() % 100;
        sendCmdRequest(EWSCmdC2S_WSHistoryMsgReq, Serialize(tWSHistoryMsgReq));
#endif
    }

    void buildPing(uint32_t requestId)
    {
        if (ping_pakcet_.size() == 0) {
            ws_packet_.iCmdType = EWSCmdC2S_HeartBeatReq;
            ws_packet_.lRequestId = g_requestId;
            ws_packet_.vData = { 'p' };
            ping_pakcet_ = std::move(Serialize(ws_packet_));
            ping_pakcet_.insert(0, 1, (char)(ping_pakcet_.size()));
            ping_pakcet_.insert(0, 1, (char)(0x80 | WebSocketPacket::opcode_type::BINARY_FRAME));
        } else {
            uint32_t* pcid = (uint32_t*)((char*)ping_pakcet_.c_str() + 8 + 2); //hack no need to Serialize
            *pcid = htonl(requestId);
        }
    }

    void pingServer()
    {
#if 0
        std::vector<taf::Char> sData = { 'p' };
        sendCmdRequest(EWSCmdC2S_HeartBeatReq, std::move(sData));
#else
        uint32_t requestId = ++g_requestId;
        if (requestId < 65536)
            requestId += 65536;

        buildPing(requestId);
        send_buf_.append(ping_pakcet_);

        {
            LOCK_GUARD;
            request2Time.insert_unique(requestId, g_nowms);
        }
#endif

        constexpr int interval = 103;
        if (g_qps % interval == interval - 1)
            wupCall();
    }

    void sendCmdRequest(int iCmdType, vector<taf::Char>&& sData)
    {
        auto requestId = (uint32_t)(++g_requestId);
        ws_packet_.iCmdType = iCmdType;
        ws_packet_.lRequestId = requestId;
        ws_packet_.vData = std::move(sData);

        int iOpcode = WebSocketPacket::opcode_type::BINARY_FRAME;
        //assert(sData.size() < 100);
        encodeWebSocket(iOpcode, std::move(Serialize(ws_packet_)));

        if (send_buf_.size() > 1024*4 && hand_state_ == 2) {
            auto send_steam = selectStream(last_stream_);
            Write(send_buf_.c_str(), send_buf_.size(), send_steam); send_buf_.clear();
        }

        LOCK_GUARD;
        request2Time.insert_unique(requestId, g_nowms);
    }

    int recvMsg(const char* data, int size)
    {
        g_qps ++;
        g_recv += size;

        ws_packet_.iCmdType = 0;
        try {
            JceInputStream<BufferReader> os;
            os.setBuffer(data, size);
            ws_packet_.readFrom(os);
        } catch (const std::exception& e) {
            printf("cmd[%d]: %s\n", (int)ws_packet_.iCmdType, e.what());
        }
        catch (...) {
            puts("unknow error");
        }

        const auto iCmdType = ws_packet_.iCmdType;
        int64_t lHearbeatStartTime = 0;
        if (ws_packet_.lRequestId != 0)
        {
            LOCK_GUARD;
            auto it = request2Time.find(ws_packet_.lRequestId);
            if (it != request2Time.end())
            {
                lHearbeatStartTime = it->second;
                request2Time._erase(it);
            }
        }

        // 新版本心跳
        if (iCmdType == EWSCmdS2C_HeartBeatRsp)
        {
            pingServer();
            if (g_qps % (1024 * 1024 * 2) == 0) {
                auto delay = int(g_nowms - lHearbeatStartTime);
                if (delay > 100)
                    printf("%s|ping delay %d ms, push %d \n", server_ip_.c_str(), delay, (int)pushMsgs_);
            }
            return 0;
        }
        else if (iCmdType == EWSCmdS2C_MsgPushReq) {
            //if (push_stream_.count(last_stream_) == 0)
            {
                pushMsgs_++, g_push++;
                groupIdPushs[groupId_] ++;
            }
#if 0
            WSPushMessage msg;
            JceInputStream<BufferReader> os;
            os.setBuffer(ws_packet_.vData.data(), ws_packet_.vData.size());
            msg.readFrom(os);
            wsCmdSize[msg.iUri] += size;
            printf("%s|uri[%ld] = %d, push_type = %d \n", server_ip_.c_str(), msg.iUri, size, msg.ePushType);
            puts("EWSCmdS2C_MsgPushReq");
#endif
        }
        else if (iCmdType == EWSCmdS2C_RegisterGroupRsp)
        {
#if 0
            WSRegisterGroupRsp msg;
            JceInputStream<BufferReader> os;
            os.setBuffer(ws_packet_.vData.data(), ws_packet_.vData.size());
            msg.readFrom(os);
            printf("EWSCmdS2C_RegisterGroupRsp %d: %d\n", msg.iResCode, (int)msg.vSupportP2PGroupId.size());
#endif
        }

#if 0
        else if (iCmdType == 0)
            puts("decodce ws error");

        // wup请求响应包
        else if(iCmdType == EWSCmd_WupRsp)
        {
            wup::UniPacket<> de;
            de.decode( ws_packet_.vData.data(), ws_packet_.vData.size());
            int ret;
            de.get( "", ret );

            WSLaunchRsp tWSLaunchRsp;
            de.get( "tRsp", tWSLaunchRsp );
        }
        else if (iCmdType == EWSCmdS2C_MsgPushReq)
        {
        }
        // 新版本合包消息
        else if (iCmdType == EWSCmdS2C_MsgPushReq_V2)
        {
        }
        else if(iCmdType == EWSCmdS2C_WSHistoryMsgRsp)
        {
        }
#endif

        wsCmdSize[iCmdType] += 1;
        if (g_requestId % 11 == 0) {
            pingServer();
        } else if (g_requestId % 101 == 1)
            login(uid_, g_qps);

        return 0;
    }
};

static void log_func(const char* cfile, int line, const char* func, const char* slog)
{
    //printf("%s %s:%d %s\n", cfile, func, line, slog);
    printf("%s %s\n", func, slog);
}

//#define IPALL 1
#include "ipList.h"

inline taf::Int32 loadConfig(const std::string& app, const std::string& server, const std::string& filename, std::string& config, const map<string, string>& context, map<string, string>* pResponseContext)
{
    taf::JceOutputStream<taf::BufferWriter> _os;
    _os.write(app, 1);
    _os.write(server, 2);
    _os.write(filename, 3);
    _os.write(config, 4);
    taf::ResponsePacket rep;
    std::map<string, string> _mStatus;


    taf::JceInputStream<taf::BufferReader> _is;
    _is.setBuffer(rep.sBuffer);
    taf::Int32 _ret;
    _is.read(_ret, 0, true);
    _is.read(config, 4, true);
    return _ret;
}

int main(int argc, char **argv)
{
    srand((unsigned)time(0));
    string config = string(100'000, 'a');
    const map<string, string> context = {
        {"key1", "value1"},
        {"key2", "value2"},
    };

    //loadConfig("HUYAWS", "WebSocketServer", "WebSocketServer.conf", config, context, nullptr);

#ifdef _WIN32
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif

    std::string wsUrl;
    int reactorCount = 1, clientCount = sizeof(ipList) / sizeof(ipList[0]);
    uint64_t debug_mask = dbg_error | dbg_warn;
    QuicSetLogFunc(log_func, debug_mask);

    puts("cmd: i(ip) t(thread) y(bbr) z(text) d(debug) l(chrome_quic_log) g(groupid) w(1-rtt) b(packet) f(0-rtt) s(stream) p(push_uri)\n");

    for (int i = 1; i < argc; i++)
    {
        const auto cmd = argv[i][0];
        const char* arg = argv[i] + 1;
        int value = atoi(arg);

        if (cmd == 'i') {
            if (value == 0)
                wsUrl = "http://112.90.94.153:443";
            else if (value == 1)
                wsUrl = "http://103.49.135.167:443";
            else
                wsUrl = string("http://") + string(arg) + string(":443");
            clientCount = 1;
        }
        else if (cmd == 'z') {
            QuicSetOption("hyc", value);
        }
        else if (cmd == 't')
            reactorCount = value;
        if (cmd == 's') {
            g_stream = value;
        }
        else if (cmd == 'y') {
            QuicSetOption("bbr", value);
            QuicSetBBR(value);
        }
        else if (cmd == 'b') {
            QuicSetOption("packet", value);
        }
        else if (cmd == 'l') {
            QuicSetOption("chrome_quic_log", value);
        }
        else if (cmd == 'o') {
            if (value > 1 && reactorCount == 1)
            QuicSetOption("share_socket", value);
        }
        else if (cmd == 'f') {
            QuicSetOption("scfg", value);
        }
        else if (cmd == 'd') {
            if (value == 0)
                debug_mask = 0;
            else if (value < 0)
                debug_mask = -1u;
            else if (value < 30)
                debug_mask |= (1ul << value);
            else
                debug_mask |= value;
            QuicSetLogFunc(log_func, debug_mask);
        }
        else if (cmd == 'g')
            sGroudIds.emplace_back(arg);
        else if (cmd == 'w')
            use_1Rtt = !use_1Rtt;
        else if (cmd == 'n')
            QuicSetOption("back_udp", value);
    }

    QuicSetOption("chrome_quic_log", 0);
    printf("reactorCount = %d has %d clients, url = %s\n", reactorCount, clientCount, wsUrl.c_str());

    vector <std::thread*> threads;
    threads.reserve(reactorCount);

    for (int i = 0; i < reactorCount; i++)
    {
        threads.emplace_back(new std::thread([=]() {
            vector <WebSocketConnection *> clients;
            clients.reserve(clientCount);
            IOService ios(false);
            auto conUrl = wsUrl;
            for (int j = 0; j < clientCount; j++) {
                if (clientCount == sizeof(ipList) / sizeof(ipList[0]))
                    conUrl = string("http://") + string(ipList[j]) + string(":443");

                g_nowms = now2ms();
                auto ptr = new WebSocketConnection(&ios);
                ptr->init(conUrl, j + 1);
                ptr->wupCall();
                ptr->login(j + 50013595, j);
                ptr->pingServer();
                clients.push_back(ptr);
                if (i % 2 == 0)
                ios.Run(1);
                //std::this_thread::sleep_for(std::chrono::milliseconds(rand() % 20));
            }

            for (;;) {
                g_nowms = now2ms();
                auto ret = ios.Run(5000);
                if (ret < 0)
                    break;
            }
            })
        );

        threads[i]->detach();
    }

    while(1) {

        int64_t now_reqs  = g_requestId;
        int64_t last_qps  = g_qps, last_recv = g_recv, last_push = g_push;

        int64_t last_ms = now2ms2();
        std::this_thread::sleep_for(std::chrono::seconds(10));
        int64_t delay     = now2ms2() - last_ms;
        int64_t now_gps   = g_qps, now_recv  = g_recv, now_push  = g_push;

        int removed = 0;
        if (request2Time.size() > 10'000 && g_spinlock.try_lock()) {
            auto delayms = now2ms() - 5'000;
            request2Time.dump_statics(1);
            for (auto it = request2Time.begin(); it != request2Time.end();) {
                if (it->second < delayms) {
                    it = request2Time.erase(it);//TODO some bug for iterator.
                    removed ++;
                } else
                    ++it;
            }
            g_spinlock.unlock();
        }

        printf("\tconns = %3d, total_recv = %5d MB, recv_qps/send_qps/push_qps = %5d/%5d/%4d, bw = %.3lf KB"\
            "\t\nsend_list %d, removed:%d, wsuri:%d, groupids: %d\n\n",
            (int)g_connection, (int)(now_recv >> 20),
            (int)((now_gps - last_qps) * 1000 / delay),
            (int)((g_requestId - now_reqs) * 1000 / delay),
            (int)((now_push - last_push) * 10000 / delay),
            (now_recv - last_recv) * 1000.0 / (1024 * delay),
            (int)request2Time.size(), removed,
            wsCmdSize.size(), groupIdPushs.size());

        if (rand() < 100)
        groupIdPushs.clear();
    }

    return 0;
}

