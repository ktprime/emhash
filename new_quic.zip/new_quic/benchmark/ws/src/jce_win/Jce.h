#ifndef __JCE_H__
#define __JCE_H__

#ifdef WIN32
#include <winsock2.h>
#include <stdint.h>
#undef snprintf
#define snprintf _snprintf_s
#elif defined(SYMBIAN)
#include <arpa/inet.h>
#include <stdint.h>
#else
#include <netinet/in.h>
#include <stdint.h>
#endif
#include <iostream>
#include <cassert>
#include <vector>
#include <map>
#include <string>
#include <stdexcept>

#include <string.h>
#include <limits.h>

//#define JEC_DEBUG_TAG

#ifdef JEC_DEBUG_TAG
#include "Logger.h"
#endif

#define JCE_UNUSED(x) (void)x

#ifdef __APPLE__
#include "JceType.h"
#else
#include "Jce/JceType.h"
#endif

#ifndef DISABLE_EXCEPTION_FOR_MOBILE
    #define DISABLE_EXCEPTION_FOR_MOBILE
#endif


namespace taf
{
//////////////////////////////////////////////////////////////////
struct JceStructBase
{
protected:
    JceStructBase() {}

    ~JceStructBase() {}
};

enum {
    ERROR_JCE_NUKNOWN = -100,
    ERROR_JCE_DECODE = -101,
    ERROR_JCE_DECODE_MISMATCH = -102,
    ERROR_JCE_DECODE_REQUIRE_NOTEXIST = -103,
    ERROR_JCE_DECODE_INVALID_VALUE = -104,
    ERROR_JCE_OUT_OF_MEMORY = -105,
    ERROR_JCE_OVERFLOW_MEMORY = -106,
};

struct JceException : public std::runtime_error
{
    JceException(const std::string& s) : std::runtime_error(s) {}
};

struct JceEncodeException : public JceException
{
    JceEncodeException(const std::string& s) : JceException(s) {}
};

struct JceDecodeException : public JceException
{
    JceDecodeException(const std::string& s) : JceException(s) {}
};

struct JceDecodeMismatch : public JceDecodeException
{
    JceDecodeMismatch(const std::string & s) : JceDecodeException(s) {}
};

struct JceDecodeRequireNotExist : public JceDecodeException
{
    JceDecodeRequireNotExist(const std::string & s) : JceDecodeException(s) {}
};

struct JceDecodeInvalidValue : public JceDecodeException
{
    JceDecodeInvalidValue(const std::string & s) : JceDecodeException(s) {}
};

struct JceNotEnoughBuff : public JceException
{
    JceNotEnoughBuff(const std::string & s) : JceException(s) {}
};

//////////////////////////////////////////////////////////////////
namespace
{
/// 数据头信息的封装，包括类型和tag
class DataHead
{
    uint8_t _type;
    uint8_t _tag;
public:
    enum
    {
        eChar = 0,
        eShort = 1,
        eInt32 = 2,
        eInt64 = 3,
        eFloat = 4,
        eDouble = 5,
        eString1 = 6,
        eString4 = 7,
        eMap = 8,
        eList = 9,
        eStructBegin = 10,
        eStructEnd = 11,
        eZeroTag = 12,
        eSimpleList = 13,
    };
#pragma pack(1)
    struct helper
    {
#if defined(WIN32) || defined(SYMBIAN)
        unsigned char    type : 4;
        unsigned char    tag : 4;
#else
		unsigned int	type : 4;
		unsigned int	tag : 4;
#endif
    };
#pragma pack()
public:
    DataHead() : _type(0), _tag(0) {}
    DataHead(uint8_t type, uint8_t tag) : _type(type), _tag(tag) {}

    uint8_t getTag() const      { return _tag; }
    void setTag(uint8_t t)      { _tag = t; }
    uint8_t getType() const     { return _type; }
    void setType(uint8_t t)     { _type = t; }

	/// 读取数据头信息
    template<typename InputStreamT>
    taf::Int32 readFrom(InputStreamT& is) {
        int n = peekFrom(is);
        is.skip(n);
        return n;
    }

	/// 读取头信息，但不前移流的偏移量
    template<typename InputStreamT>
    taf::Int32 peekFrom(InputStreamT& is) {
        helper h = {0,0};
        taf::Int32 n = sizeof(h);
        is.peekBuf(&h, sizeof(h));
        _type = h.type;
        if(h.tag == 15){
            is.peekBuf(&_tag, sizeof(_tag), sizeof(h));
            n += sizeof(_tag);
        }else{
            _tag = h.tag;
        }
        return n;
    }

	/// 写入数据头信息
    template<typename OutputStreamT>
    taf::Int32 writeTo(OutputStreamT& os) {
        return writeTo(os, _type, _tag);
    }

	/// 写入数据头信息
    template<typename OutputStreamT>
    static taf::Int32 writeTo(OutputStreamT& os, uint8_t type, uint8_t tag) {
        helper h;
        h.type = type;
        taf::Int32 len = sizeof(h);
        if(tag < 15){
            h.tag = tag;
            len = os.writeBuf(&h, len);
        }else{
            h.tag = 15;
            os.writeBuf(&h, len);
            len = os.writeBuf(&tag, sizeof(tag));
        }
        return len;
    }
};
}


//////////////////////////////////////////////////////////////////
/// 缓冲区读取器封装
class BufferReader
{
    const char *        _buf;       ///< 缓冲区
    size_t              _buf_len;   ///< 缓冲区长度
    size_t              _cur;       ///< 当前位置

public:

    BufferReader() : _cur(0) {}

    void reset() { _cur = 0; }

	/// 读取缓存
    taf::Int32 readBuf(void * buf, size_t len) {
        taf::Int32 t = peekBuf(buf, len);
        if(t>0) {
            _cur += t;
        }
        return t;
    }

	/// 读取缓存，但不改变偏移量
    taf::Int32 peekBuf(void * buf, size_t len, size_t offset = 0) {
        if(_cur + offset + len > _buf_len) {
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "buffer overflow when peekBuf, over %u.", (uint32_t)_buf_len);
            throw JceDecodeException(s);
#else
            return ERROR_JCE_OVERFLOW_MEMORY;
#endif
        }
        ::memcpy(buf, _buf + _cur + offset, len);
        return (taf::Int32)len;
    }

	/// 跳过len个字节
    void skip(size_t len) {
        _cur += len;
    }

	/// 设置缓存
    void setBuffer(const char * buf, size_t len) {
        _buf = buf;
        _buf_len = len;
        _cur = 0;
    }

	/// 设置缓存
    template<typename Alloc>
    void setBuffer(const std::vector<char,Alloc> &buf) {
        _buf = &buf[0];
        _buf_len = buf.size();
        _cur = 0;
    }

	/**
	 * 判断是否已经到BUF的末尾
	 */
	bool hasEnd() {
		return _cur >= _buf_len;
	}
	size_t tellp() const {
		return _cur;
	}
	const char* base() const {
		return _buf;
	}
};

//当jce文件中含有指针型类型的数据用MapBufferReader读取
//在读数据时利用MapBufferReader提前分配的内存 减少运行过程中频繁内存分配
//结构中定义byte指针类型，指针用*来定义，如下：
//byte *m;
//指针类型使用时需要MapBufferReader提前设定预分配内存块setMapBuffer()，
//指针需要内存时通过偏移指向预分配内存块，减少解码过程中的内存申请
class MapBufferReader : public BufferReader
{

public:
    MapBufferReader() : _buf(NULL), _buf_len(0), _cur(0) {}

    void reset() { _cur = 0; BufferReader::reset(); }

    char* cur() {
        if(_buf == NULL) {

#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "MapBufferReader's buff not set, _buf = null");
            throw JceDecodeException(s);
#else
            return NULL;
#endif
        }
        return _buf+_cur;
    }

    taf::Int32 left() { return (taf::Int32)(_buf_len-_cur); }

    /// 跳过len个字节
    taf::Int32 mapBufferSkip(size_t len) {
        if(_cur + len > _buf_len) {
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "MapBufferReader's buffer overflow when peekBuf, over %u.", (uint32_t)_buf_len);
            throw JceDecodeException(s);
#else
            return ERROR_JCE_OVERFLOW_MEMORY;
#endif
        }
        _cur += len;
        return (taf::Int32)len;
    }

    /// 设置缓存
    void setMapBuffer(char * buf, size_t len)  {
        _buf = buf;
        _buf_len = len;
        _cur = 0;
    }

    /// 设置缓存
    template<typename Alloc>
    void setMapBuffer(std::vector<char,Alloc> &buf) {
        _buf = &buf[0];
        _buf_len = buf.size();
        _cur = 0;
    }
public:
    char *              _buf;       ///< 缓冲区
    size_t              _buf_len;   ///< 缓冲区长度
    size_t              _cur;       ///< 当前位置
};

//////////////////////////////////////////////////////////////////
/// 缓冲区写入器封装
class BufferWriter
{
    char *  _buf;
    size_t  _len;
    size_t  _buf_len;

public:
    BufferWriter(const BufferWriter & bw) {
        _buf = NULL;
        _len = 0;
        _buf_len = 0;

        writeBuf(bw._buf, bw._len);
        _len = bw._len;
        //_buf_len   = bw._buf_len;
    }

    BufferWriter& operator=(const BufferWriter& buf) {
        writeBuf(buf._buf,buf._len);
        _len = buf._len;
        //_buf_len = buf._buf_len;
        return *this;
    }

    BufferWriter()
        : _buf(NULL)
        , _len(0)
        , _buf_len(0)
    {}
    ~BufferWriter() {
        delete[] _buf;
    }
    void reserve(size_t len) {
        if(_buf_len < len) {
            len *= 2;
            char * p = new char[len];
            memcpy(p, _buf, _len);
            delete[] _buf;
            _buf = p;
            _buf_len = len;
        }
    }
    void reset() { _len = 0; }

    taf::Int32 writeBuf(const void * buf, size_t len) {
        reserve(_len + len);
        memcpy(_buf + _len, buf, len);
        _len += len;
        return (taf::Int32)len;
    }

    std::vector<char> getByteBuffer() const      { return std::vector<char>(_buf, _buf + _len); }
    const char * getBuffer() const                      { return _buf; }//{ return &_buf[0]; }
    size_t getLength() const                            { return _len; } //{ return _buf.size(); }
    void swap(std::vector<char>& v) {
        v.assign(_buf, _buf + _len);
    }
    void swap(BufferWriter& buf) {
        std::swap(_buf, buf._buf);
        std::swap(_buf_len, buf._buf_len);
        std::swap(_len, buf._len);
    }
};

///////////////////////////////////////////////////////////////////////////////////////////////////
/// 预先设定缓存的封装器

class BufferWriterBuff
{
    char *  _buf;
    size_t  _len;
    size_t  _buf_len;

    BufferWriterBuff(const BufferWriterBuff&);
public:

    BufferWriterBuff& operator=(const BufferWriterBuff& buf) {
        writeBuf(buf._buf, buf._len);
        _len = buf._len;
        _buf_len = buf._buf_len;
        return *this;
    }

    BufferWriterBuff()
        : _buf(NULL)
        , _len(0)
        , _buf_len(0)
    {}
    ~BufferWriterBuff() { }

    void setBuffer(char * buffer, size_t size_buff) {
        _buf = buffer;
        _len = 0;
        _buf_len = size_buff;
    }

    void reset() { _len = 0; }

    taf::Int32 writeBuf(const void * buf, size_t len) {
        if (_buf_len < _len + len) {
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            throw JceNotEnoughBuff("not enough buffer");
#else
            return ERROR_JCE_OUT_OF_MEMORY;
#endif
        }
        memcpy(_buf + _len, buf, len);
        _len += len;
        return (taf::Int32)len;
    }

    std::vector<char> getByteBuffer() const      { return std::vector<char>(_buf, _buf + _len); }
    const char * getBuffer() const               { return _buf; }
    size_t getLength() const                     { return _len; }
    void swap(std::vector<char>& v) {
        v.assign(_buf, _buf + _len);
    }
    void swap(BufferWriterBuff& buf) {
        std::swap(_buf, buf._buf);
        std::swap(_buf_len, buf._buf_len);
        std::swap(_len, buf._len);
    }
};

//////////////////////////////////////////////////////////////////
template<typename ReaderT = BufferReader>
class JceInputStream : public ReaderT
{
public:
	/// 跳到指定标签的元素前
    bool skipToTag(uint8_t tag) {
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
        try{
#endif
            DataHead h;
			while (!ReaderT::hasEnd()) {
				taf::Int32 len = h.peekFrom(*this);
				if (tag <= h.getTag() || h.getType() == DataHead::eStructEnd)
					return h.getType() == DataHead::eStructEnd ? false : (tag == h.getTag());
				this->skip(len);
				skipField(h.getType());
			}
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
        }catch(JceDecodeException&){
        }
#endif
        return false;
    }

	/// 跳到当前结构的结束
    bool skipToStructEnd() {
        DataHead h;
        do{
            int len = h.readFrom(*this);
            if(len<0) {
                return len;
            }
            if(skipField(h.getType())<0) {
                return false;
            }
        }while(h.getType() != DataHead::eStructEnd);
        return true;
    }

	/// 跳过一个字段
    taf::Int32 skipField() {
        DataHead h;
        taf::Int32 len = h.readFrom(*this);
        if(len<0) {
            return len;
        }
        return skipField(h.getType());
    }

	/// 跳过一个字段，不包含头信息
    taf::Int32 skipField(uint8_t type) {
        taf::Int32 len = 0;
        switch(type){
        case DataHead::eChar:
            len = sizeof(char);
            this->skip(len);
            break;
        case DataHead::eShort:
            len = sizeof(Short);
            this->skip(len);
            break;
        case DataHead::eInt32:
            len = sizeof(Int32);
            this->skip(len);
            break;
        case DataHead::eInt64:
            len = sizeof(Int64);
            this->skip(len);
            break;
        case DataHead::eFloat:
            len = sizeof(Float);
            this->skip(len);
            break;
        case DataHead::eDouble:
            len = sizeof(Double);
            this->skip(len);
            break;
        case DataHead::eString1: {
            len = readByType<uint8_t>();
            this->skip(len);
        } break;
        case DataHead::eString4: {
            len = ntohl(readByType<uint32_t>());
            this->skip(len);
        } break;
        case DataHead::eMap: {
            Int32 size = 0;
            len = read(size, 0);
            if(len<0) {
                break;
            }
            for(Int32 i = 0; i < size * 2; ++i) {
                len = skipField();
                if(len<0) {
                    break;
                }
            }
        } break;
        case DataHead::eList: {
            Int32 size = 0;
            len = read(size, 0);
            if(len<0) {
                break;
            }
            for(Int32 i = 0; i < size; ++i) {
                len = skipField();
                if(len<0) {
                    break;
                }
            }
        } break;
        case DataHead::eSimpleList: {
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) { break; }
            if(h.getType() != DataHead::eChar){
                len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "skipField with invalid type, type value: %d, %d.", type, h.getType());
                throw JceDecodeMismatch(s);
#else
                break;
#endif
            }
            Int32 size = 0;
            len = read(size, 0);
            if(len<0) { break; }
            this->skip(size);
        } break;
        case DataHead::eStructBegin:
            len = skipToStructEnd() ? 0 : ERROR_JCE_DECODE;
            break;
        case DataHead::eStructEnd:
        case DataHead::eZeroTag:
            break;
        default: {
            len = ERROR_JCE_DECODE_INVALID_VALUE;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "skipField with invalid type, type value:%d.", type);
            throw JceDecodeMismatch(s);
#endif
            }
        }
        return len;
    }

	/// 读取一个指定类型的数据（基本类型）
    template<typename T>
    inline T readByType() {
        T n = 0;
        this->readBuf(&n, sizeof(n));
        return n;
	}
	taf::Int32 readUnknown(std::string & sUnkown, uint8_t tag) {
		taf::Int32 len = 0;
		size_t start = ReaderT::tellp();
		size_t last  = start;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
		try
		{
#endif
			uint8_t lasttag = tag;
			DataHead h;
			while (!ReaderT::hasEnd()) {
				size_t temp = h.peekFrom(*this);
				if ( h.getTag() <=lasttag) {
					len = temp;
					break;
				}
				lasttag = h.getTag();
				this->skip(temp);
				skipField(h.getType());
				last = ReaderT::tellp(); //记录下最后一次正常到达的位置
			}
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
		}
		catch (...) //
		{
			throw;
		}
#endif
		std::string s(ReaderT::base() +start, last - start);
		sUnkown = s;
		return len;

	}
    friend class XmlProxyCallback;

    taf::Int32 read(Bool& b, uint8_t tag, bool isRequire = true) {
        Char c = b;
        taf::Int32 len = read(c, tag, isRequire);
        b = c ? true : false;
#ifdef JEC_DEBUG_TAG
        loge("decode-info jce-read Bool len:%d, data:%c", len, b);
#endif
        return len;
    }

    taf::Int32 read(Char& c, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)) {
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) {
                return len;
            }
            switch(h.getType()) {
            case DataHead::eZeroTag:
                c = 0;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Char-eZeroTag len:%d, data:%d", len, c);
#endif
                break;
            case DataHead::eChar:
                len = this->readBuf(&c, sizeof(c));
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Char-eChar len:%d, data:%d", len, c);
#endif
                break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Char-mismatch len:%d, tag:%d, type:%d.", len, tag, h.getType());
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'Char' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        } else if(isRequire) {
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifdef JEC_DEBUG_TAG
            loge("decode-info jce-read Char-not exist len:%d, tag:%d", len, tag);
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d.", tag);
            throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    taf::Int32 read(UInt8& n, uint8_t tag, bool isRequire = true) {
        Short i;
        taf::Int32 len = read(i, tag, isRequire);
        n = (UInt8)i;
#ifdef JEC_DEBUG_TAG
        loge("decode-info jce-read UInt8 len:%d, data:%d", len, n);
#endif
        return len;
    }

    taf::Int32 read(Short& n, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)) {
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) {
                return len;
            }
            switch(h.getType()) {
            case DataHead::eZeroTag: {
                n = 0;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Short-eZeroTag len:%d, data:%d", len, n);
#endif
            } break;
            case DataHead::eChar: {
                n = readByType<Char>();
                len = n;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Short-eChar len:%d, data:%d", len, n);
#endif
            } break;
            case DataHead::eShort: {
                len = this->readBuf(&n, sizeof(n));
                n = ntohs(n);
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Short-eShort len:%d, data:%d", len, n);
#endif
            } break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Short-eShort len:%d, tag:%d, type:%d", len, tag, h.getType());
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'Short' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        } else if(isRequire) {
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifdef JEC_DEBUG_TAG
            loge("decode-info jce-read Short-eShort len:%d, tag:%d", len, tag);
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
            throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    taf::Int32 read(UInt16& n, uint8_t tag, bool isRequire = true) {
        Int32 i;
        taf::Int32 len = read(i,tag,isRequire);
        n = (UInt16)i;
#ifdef JEC_DEBUG_TAG
        loge("decode-info jce-read UInt16 len:%d, data:%d", len, n);
#endif
        return len;
    }

    taf::Int32 read(Int32& n, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) {
                return len;
            }
            switch(h.getType()){
            case DataHead::eZeroTag: {
                n = 0;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int32-eZeroTag len:%d, data:%d",  len,  n);
#endif
            } break;
            case DataHead::eChar: {
                n = readByType<Char>();
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int32-eChar len:%d, data:%d", len, n);
#endif
            } break;
            case DataHead::eShort: {
                n = (Short) ntohs(readByType<Short>());
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int32-eShort len:%d, data:%d", len, n);
#endif
            } break;
            case DataHead::eInt32: {
                len = this->readBuf(&n, sizeof(n));
                n = ntohl(n);
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int32-eInt32 len:%d, data:%d", len, n);
#endif
            } break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int32-mismatch len:%d, tag:%d, type:%d", len, tag, h.getType());
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'Int32' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        } else if(isRequire) {
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifdef JEC_DEBUG_TAG
            loge("decode-info jce-read Int32-not exist len:%d, tag:%d", len, tag);
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
            throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    taf::Int32 read(UInt32& n, uint8_t tag, bool isRequire = true) {
        Int64 i = 0;
        taf::Int32 len = read(i,tag,isRequire);
        n = (UInt32)i;
#ifdef JEC_DEBUG_TAG
        loge("decode-info jce-read UInt32 len:%d, data:%d", len, n);
#endif
        return len;
    }

    taf::Int32 read(Int64& n, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) {
                return len;
            }
            switch(h.getType()){
            case DataHead::eZeroTag: {
                n = 0;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int64-eZeroTag len:%d, data:%lld", len, n);
#endif
            } break;
            case DataHead::eChar: {
                n = readByType<Char>();
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int64-eChar len:%d, data:%lld", len, n);
#endif
            } break;
            case DataHead::eShort: {
                n = (Short) ntohs(readByType<Short>());
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int64-eShort len:%d, data:%lld", len, n);
#endif
            } break;
            case DataHead::eInt32: {
                n = (Int32) ntohl(readByType<Int32>());
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int64-eInt32 len:%d, data:%lld", len, n);
#endif
            } break;
            case DataHead::eInt64: {
                len = this->readBuf(&n, sizeof(n));
                n = jce_ntohll(n);
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int64-eInt64 len:%d, data:%lld", len, n);
#endif
            } break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read Int64-mismatch len:%d, tag:%d, type:%d", len, tag, h.getType());
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    char s[64];
                    snprintf(s, sizeof(s), "read 'Int64' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                    throw JceDecodeMismatch(s);
#endif
                }
            }
        } else if(isRequire) {
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifdef JEC_DEBUG_TAG
            loge("decode-info jce-read Int64-not exist len:%d, tag:%d", len, tag);
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
            throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    taf::Int32 read(Float& n, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) {
                return len;
            }
            switch(h.getType()) {
            case DataHead::eZeroTag:
                n = 0;
                break;
            case DataHead::eFloat: {
                len = this->readBuf(&n, sizeof(n));
                n = jce_ntohf(n);
            } break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'Float' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        } else if(isRequire) {
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
            throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    taf::Int32 read(Double& n, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) {
                return len;
            }
            switch(h.getType()) {
            case DataHead::eZeroTag:
                n = 0;
                break;
            case DataHead::eFloat: {
                n = readByType<Float>();
                len = n;
                n = jce_ntohf(n);
            } break;
            case DataHead::eDouble: {
                len = this->readBuf(&n, sizeof(n));
                n = jce_ntohd(n);
            } break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'Double' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        } else if(isRequire){
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
            throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    taf::Int32 read(std::string& s, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) { return len; }
            switch(h.getType()){
            case DataHead::eString1: {
                size_t rlen = readByType<uint8_t>();
                char ss[256];
                len = this->readBuf(ss, rlen);
                s.assign(ss, ss + rlen);
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read eString1 len:%d, s:%s", rlen, s.c_str());
#endif
            } break;
            case DataHead::eString4: {
                len = ntohl(readByType<uint32_t>());
                if(len > JCE_MAX_STRING_LENGTH) {
#ifdef JEC_DEBUG_TAG
                    loge("decode-info jce-read eString4 invalid string size, tag:%d, len:%d", tag, len);
#endif
                    len = ERROR_JCE_DECODE_INVALID_VALUE;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    char s[128];
                    snprintf(s, sizeof(s), "invalid string size, tag: %d, size: %d", tag, len);
                    throw JceDecodeInvalidValue(s);
#else
                    break;
#endif
                }
                char *ss = new char[len];
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                try{
#endif
                    len = this->readBuf(ss, len);
                    s.assign(ss, ss + len);
#ifdef JEC_DEBUG_TAG
                    loge("decode-info jce-read eString4 len:%d, s:%s", len, s.c_str());
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    } catch(...) {
                        delete[] ss;
                        ss = NULL;
                        throw;
                    }
#endif
                    if(ss!=NULL) {
                        delete[] ss;
                    }
                }
                break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifdef JEC_DEBUG_TAG
                loge("decode-info jce-read string mismatch, tag:%d", tag);
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'string' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        } else if(isRequire) {
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifdef JEC_DEBUG_TAG
            loge("decode-info jce-read string not exist, tag:%d", tag);
#endif
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
            throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    taf::Int32 read(char *buf, const UInt32 bufLen, UInt32 & readLen, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)) {
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) { return len; }
             switch(h.getType())
             {
                case DataHead::eSimpleList: {
                    DataHead hh;
                    len = hh.readFrom(*this);
                    if(hh.getType() != DataHead::eChar) {
                        len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                        char s[128];
                        snprintf(s, sizeof(s), "type mismatch, tag: %d, type: %d, %d", tag, h.getType(), hh.getType());
						throw JceDecodeMismatch(s);
#else
                        break;
#endif
                    }
                    UInt32 size = 0;
                    len = read(size, 0);
                    if(size > bufLen) {
                        len = ERROR_JCE_DECODE_INVALID_VALUE;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                        char s[128];
                        snprintf(s, sizeof(s), "invalid size, tag: %d, type: %d, %d, size: %d", tag, h.getType(), hh.getType(), size);
						throw JceDecodeInvalidValue(s);
#else
                        break;
#endif
                    }
                    len = this->readBuf(buf, size);
                    readLen = size;
                } break;
                default: {
                    len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    char s[128];
                    snprintf(s, sizeof(s), "type mismatch, tag: %d, type: %d", tag, h.getType());
					throw JceDecodeMismatch(s);
#endif
                }
            }
        }
        else if(isRequire)
        {
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[128];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
            throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    template<typename K, typename V, typename Cmp, typename Alloc>
    taf::Int32 read(std::map<K, V, Cmp, Alloc>& m, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) { return len; }
            switch(h.getType()){
            case DataHead::eMap: {
                Int32 size = 0;
                len = read(size, 0);
                if(size < 0) {
                    len = ERROR_JCE_DECODE_INVALID_VALUE;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    char s[128];
                    snprintf(s, sizeof(s), "invalid map, tag: %d, size: %d", tag, size);
                    throw JceDecodeInvalidValue(s);
#else
                    break;
#endif
                }
                m.clear();
                std::pair<K, V> pr;
                for(Int32 i = 0; i < size; ++i){
                    len = read(pr.first, 0);
                    len = read(pr.second, 1);
                    m.insert(pr);
                }
            } break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'map' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        } else if(isRequire) {
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
			throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    template<typename Alloc>
    taf::Int32 read(std::vector<Char, Alloc>& v, uint8_t tag, bool isRequire = true) {
        taf::Int32 len = 0;
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) { return len; }
            switch(h.getType()){
            case DataHead::eSimpleList: {
                DataHead hh;
                len = hh.readFrom(*this);
                if(hh.getType() != DataHead::eChar){
                    len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    char s[128];
                    snprintf(s, sizeof(s), "type mismatch, tag: %d, type: %d, %d", tag, h.getType(), hh.getType());
                    throw JceDecodeMismatch(s);
#else
                    break;
#endif
                }
                Int32 size = 0;
                len = read(size, 0);
                if(size < 0){
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    char s[128];
                    snprintf(s, sizeof(s), "invalid size, tag: %d, type: %d, %d, size: %d", tag, h.getType(), hh.getType(), size);
                    throw JceDecodeInvalidValue(s);
#else
                    break;
#endif
                }
                v.resize(size);
                len = this->readBuf(&v[0], size);
            } break;
            case DataHead::eList: {
                Int32 size = 0;
                len = read(size, 0);
                if(size < 0){
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    char s[128];
                    snprintf(s, sizeof(s), "invalid size, tag: %d, type: %d, size: %d", tag, h.getType(), size);
                    throw JceDecodeInvalidValue(s);
#else
                    break;
#endif
                }
                v.resize(size);
                for(Int32 i = 0; i < size; ++i)
                    read(v[i], 0);
            } break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[128];
                snprintf(s, sizeof(s), "type mismatch, tag: %d, type: %d", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        }else if(isRequire){
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[128];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
			throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    template<typename T, typename Alloc>
    taf::Int32 read(std::vector<T, Alloc>& v, uint8_t tag, bool isRequire = true)
    {
        taf::Int32 len = 0;
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) { return len; }
            switch(h.getType()){
            case DataHead::eList: {
                Int32 size = 0;
                len = read(size, 0);
                if(size < 0){
                    len = ERROR_JCE_DECODE_INVALID_VALUE;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    char s[128];
                    snprintf(s, sizeof(s), "invalid size, tag: %d, type: %d, size: %d", tag, h.getType(), size);
                    throw JceDecodeInvalidValue(s);
#else
                    break;
#endif
                }
                v.resize(size);
                for(Int32 i = 0; i < size; ++i)
                    read(v[i], 0);
            } break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'vector' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        }else if(isRequire){
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
			throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

	/// 读取结构数组
    template<typename T>
    taf::Int32 read(T* v, const UInt32 vlen, UInt32 & readLen, uint8_t tag, bool isRequire = true)
    {
        taf::Int32 len = 0;
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) { return len; }
            switch(h.getType()){
            case DataHead::eList: {
                Int32 size = 0;
                len = read(size, 0);
                if(size < 0 ){
                    len = ERROR_JCE_DECODE_INVALID_VALUE;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                    char s[128];
                    snprintf(s, sizeof(s), "invalid size, tag: %d, type: %d, size: %d", tag, h.getType(), size);
                    throw JceDecodeInvalidValue(s);
#else
                    break;
#endif
                }
                for(Int32 i = 0; i < size; ++i)
                    read(v[i], 0);
                readLen = size;
            } break;
            default: {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'vector struct' type mismatch, tag: %d, get type: %d.", tag, h.getType());
                throw JceDecodeMismatch(s);
#endif
                }
            }
        }else if(isRequire){
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
			throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }

    template<typename T>
    taf::Int32 read(T& v, uint8_t tag, bool isRequire = true, typename jce::disable_if<jce::is_convertible<T*, JceStructBase*>, void ***>::type dummy = 0)
    {
        Int32 n = 0;
        taf::Int32 len = read(n, tag, isRequire);
        v = (T) n;
        return len;
    }

	/// 读取结构
    template<typename T>
    taf::Int32 read(T& v, uint8_t tag, bool isRequire = true, typename jce::enable_if<jce::is_convertible<T*, JceStructBase*>, void ***>::type dummy = 0)
    {
        taf::Int32 len = 0;
		JCE_UNUSED( dummy );
        if(skipToTag(tag)){
            DataHead h;
            len = h.readFrom(*this);
            if(len<0) { return len; }
            if(h.getType() != DataHead::eStructBegin) {
                len = ERROR_JCE_DECODE_MISMATCH;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char s[64];
                snprintf(s, sizeof(s), "read 'struct' type mismatch, tag: %d, get type: %d.", tag, h.getType());
				throw JceDecodeMismatch(s);
#else
                return len;
#endif
            }
            v.readFrom(*this);
            skipToStructEnd();
        }else if(isRequire){
            len = ERROR_JCE_DECODE_REQUIRE_NOTEXIST;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
            char s[64];
            snprintf(s, sizeof(s), "require field not exist, tag: %d", tag);
			throw JceDecodeRequireNotExist(s);
#endif
        }
        return len;
    }
};

//////////////////////////////////////////////////////////////////
template<typename WriterT = BufferWriter>
class JceOutputStream : public WriterT
{
public:
    taf::Int32 write(Bool b, uint8_t tag) {
        return write((Char) b, tag);
    }

    taf::Int32 write(Char n, uint8_t tag) {
        taf::Int32 len = 0;
        if (n == 0) {
            len = DataHead::writeTo(*this, DataHead::eZeroTag, tag);
        } else {
            len = DataHead::writeTo(*this, DataHead::eChar, tag);
            if(len>0) {
                len = this->writeBuf(&n, sizeof(n));
            }
        }
        return len;
    }

    taf::Int32 write(UInt8 n, uint8_t tag) {
        return write((Short) n, tag);
    }

    taf::Int32 write(Short n, uint8_t tag) {
        taf::Int32 len = 0;
        if(n >= (-128) && n <= 127){
            len = write((Char) n, tag);
        }else{
            len = DataHead::writeTo(*this, DataHead::eShort, tag);
            if(len>0) {
                n = htons(n);
                len = this->writeBuf(&n, sizeof(n));
            }
        }
        return len;
    }

    taf::Int32 write(UInt16 n, uint8_t tag) {
        return write((Int32) n, tag);
    }

    taf::Int32 write(Int32 n, uint8_t tag) {
        taf::Int32 len = 0;
        if(n >= (-32768) && n <= 32767){
            len = write((Short) n, tag);
        }else{
            len = DataHead::writeTo(*this, DataHead::eInt32, tag);
            if(len>0) {
                n = htonl(n);
                len = this->writeBuf(&n, sizeof(n));
            }
        }
        return len;
    }

    taf::Int32 write(UInt32 n, uint8_t tag) {
        return write((Int64) n, tag);
    }

    taf::Int32 write(Int64 n, uint8_t tag) {
        taf::Int32 len = 0;
        if(n >= (-2147483647-1) && n <= 2147483647){
            len = write((Int32) n, tag);
        }else{
            len = DataHead::writeTo(*this, DataHead::eInt64, tag);
            if(len>0) {
                n = jce_htonll(n);
                len = this->writeBuf(&n, sizeof(n));
            }
        }
        return len;
    }

    taf::Int32 write(Float n, uint8_t tag) {
        taf::Int32 len = DataHead::writeTo(*this, DataHead::eFloat, tag);
        if(len>0) {
            n = jce_htonf(n);
            return this->writeBuf(&n, sizeof(n));
        }
        return len;
    }

    taf::Int32 write(Double n, uint8_t tag) {
        taf::Int32 len = DataHead::writeTo(*this, DataHead::eDouble, tag);
        if(len>0) {
            n = jce_htond(n);
            return this->writeBuf(&n, sizeof(n));
        }
        return len;
    }

    taf::Int32 write(const std::string& s, uint8_t tag) {
        taf::Int32 len = 0;
        if(s.size() > 255){
            if(s.size() > JCE_MAX_STRING_LENGTH) {
                len = ERROR_JCE_DECODE_INVALID_VALUE;
#ifndef DISABLE_EXCEPTION_FOR_MOBILE
                char ss[128];
                snprintf(ss, sizeof(ss), "invalid string size, tag: %d, size: %u", tag, (uint32_t)s.size());
				throw JceDecodeInvalidValue(ss);
#else
                return len;
#endif
            }
            len = DataHead::writeTo(*this, DataHead::eString4, tag);
            if(len>0) {
                uint32_t n = htonl(s.size());
                len = this->writeBuf(&n, sizeof(n));
                if(len>0) {
                    len = this->writeBuf(s.data(), s.size());
                }
            }
        }else{
            len = DataHead::writeTo(*this, DataHead::eString1, tag);
            if(len>0) {
                uint8_t n = s.size();
                len = this->writeBuf(&n, sizeof(n));
                if(len>0) {
                    len = this->writeBuf(s.data(), s.size());
                }
            }
        }
        return len;
    }

    taf::Int32 write(const char *buf, const UInt32 size, uint8_t tag) {
        taf::Int32 len = DataHead::writeTo(*this, DataHead::eSimpleList, tag);
        if(len>0) {
            len = DataHead::writeTo(*this, DataHead::eChar, 0);
            if(len>0) {
                len = write(size, 0);
                if(len>0) {
                    return this->writeBuf(buf, size);
                }
            }
        }
        return len;
    }

    template<typename K, typename V, typename Cmp, typename Alloc>
    taf::Int32 write(const std::map<K, V, Cmp, Alloc>& m, uint8_t tag)
    {
        taf::Int32 len = DataHead::writeTo(*this, DataHead::eMap, tag);
        if(len>0) {
            Int32 n = (Int32)m.size();
            len = write(n, 0);
            if(len>0) {
                typedef typename std::map<K, V, Cmp, Alloc>::const_iterator IT;
                for (IT i = m.begin(); i != m.end(); ++i) {
                    write(i->first, 0);
                    write(i->second, 1);
                }
            }
        }
        return len;
    }

    template<typename T, typename Alloc>
    taf::Int32 write(const std::vector<T, Alloc>& v, uint8_t tag)
    {
        taf::Int32 len = DataHead::writeTo(*this, DataHead::eList, tag);
        if(len>0) {
            Int32 n = (Int32)v.size();
            len = write(n, 0);
            if(len>0) {
                typedef typename std::vector<T, Alloc>::const_iterator IT;
                for (IT i = v.begin(); i != v.end(); ++i)
                    write(*i, 0);
            }
        }
        return len;
    }

    template<typename T>
    taf::Int32 write(const T *v, const UInt32 size, uint8_t tag)
    {
        taf::Int32 len = DataHead::writeTo(*this, DataHead::eList, tag);
        if(len>0) {
            len = write(size, 0);
            if(len>0) {
                for (Int32 i = 0; i < (Int32) size; ++i) {
                    write(v[i], 0);
                }
            }
        }
        return len;
    }

    template<typename Alloc>
    taf::Int32 write(const std::vector<Char, Alloc>& v, uint8_t tag)
    {
        taf::Int32 len = DataHead::writeTo(*this, DataHead::eSimpleList, tag);
        if(len>0) {
            len = DataHead::writeTo(*this, DataHead::eChar, 0);
            if(len>0) {
                Int32 n = (Int32)v.size();
                len = write(n, 0);
                if(len>0) {
                    this->writeBuf(&v[0], v.size());
                }
            }
        }
        return len;
    }

    template<typename T>
    taf::Int32 write(const T& v, uint8_t tag, typename jce::disable_if<jce::is_convertible<T*, JceStructBase*>, void ***>::type dummy = 0){
        return write((Int32) v, tag);
    }

    template<typename T>
    taf::Int32 write(const T& v, uint8_t tag, typename jce::enable_if<jce::is_convertible<T*, JceStructBase*>, void ***>::type dummy = 0)
    {
		JCE_UNUSED( dummy );
        taf::Int32 len = DataHead::writeTo(*this, DataHead::eStructBegin, tag);
        if(len>0) {
            v.writeTo(*this);
            DataHead::writeTo(*this, DataHead::eStructEnd, 0);
        }
        return len;
    }
};
////////////////////////////////////////////////////////////////////////////////////////////////////
}

//???iphone
#ifdef __APPLE__
#include "JceDisplayer.h"
#else
#include "Jce/JceDisplayer.h"
#endif

#endif
