#ifndef __JCEHELPER_H__
#define __JCEHELPER_H__

#include <vector>
#include <string>
#include "Jce.h"
using namespace std;

namespace JceSerialize
{
    template<typename T>
    class isJceSerializable;

    template <typename T, typename _ = void>
    struct isJceVector
    {
        static const bool value = false;
    };
    template <typename T>
    struct isJceVector<T, typename std::enable_if<std::is_same<T, std::vector<typename T::value_type, typename T::allocator_type > >::value >::type >
    {
        static const bool value = isJceSerializable<typename T::value_type>::value;
    };
    template <typename T, typename _ = void>
    struct isJceMap
    {
        static const bool value = false;
    };
    template <typename T>
    struct isJceMap<T, typename std::enable_if<std::is_same<T, std::map<typename T::key_type, typename T::mapped_type, typename T::key_compare, typename T::allocator_type > >::value >::type >
    {
        static const bool value = isJceSerializable<typename T::key_type>::value && isJceSerializable<typename T::mapped_type>::value;
    };

    template<typename T>
    struct isJceSerializable
    {
        static constexpr bool value = std::is_same<T, taf::Char>::value || std::is_same<T, taf::Short>::value || std::is_same<T, taf::Int32 >::value || std::is_same<T, taf::Int64>::value
                                      || std::is_same<T, taf::UInt8>::value || std::is_same<T, taf::UInt16>::value || std::is_same<T, taf::UInt32>::value || std::is_same<T, string>::value
                                      || std::is_same<T, taf::Float>::value || std::is_same<T, taf::Double>::value || std::is_base_of<taf::JceStructBase, T>::value
                                      || isJceVector<T>::value || isJceMap<T>::value;
    };

    namespace JceSerializeImp
    {
        template<typename T>
        struct JceToVectorOrString
        {
            operator std::vector<taf::Char>()
            {
                return os.getByteBuffer();
            }
            operator std::string()
            {
                return std::string( os.getBuffer(), os.getLength() );
            }
            std::string toStr()
            {
                return *this;
            }
            std::vector<taf::Char> toVec()
            {
                return *this;
            }
            JceToVectorOrString( taf::JceOutputStream<taf::BufferWriter> &os )
                : os( os )
            {
            }
			JceToVectorOrString(JceToVectorOrString &js)
				:os(js.os)
			{

			}
       // protected:
            JceToVectorOrString(const JceToVectorOrString&) {}; //不允许直接接受返回值,必须转换为string或vector<taf::Char>
            void operator=( const JceToVectorOrString & );
        protected:
            taf::JceOutputStream<taf::BufferWriter> os;
        };

        inline bool JceReadRawData( taf::JceInputStream<taf::BufferReader> &tReader, std::string &ret )
        {
            using namespace std;
            using namespace taf;
            ret.clear();
            taf::DataHead h;
            h.readFrom( tReader );

            switch( h.getType() )
            {
            case taf::DataHead::eZeroTag:
                ret = "0";
                break;

            case taf::DataHead::eChar:
                ret = std::to_string( ( short )tReader.readByType<char>() );
                break;

            case taf::DataHead::eShort:
                ret = std::to_string( ntohs( tReader.readByType<short>() ) );
                break;

            case taf::DataHead::eInt32:
                ret = std::to_string( ntohl( tReader.readByType<taf::Int32>() ) );
                break;

            case taf::DataHead::eInt64:
                ret = std::to_string( jce_ntohll( tReader.readByType<taf::Int64>() ) );
                break;

            case taf::DataHead::eFloat:
                ret = std::to_string( jce_ntohf( tReader.readByType<float>() ) );
                break;

            case taf::DataHead::eDouble:
                ret = std::to_string( jce_ntohd( tReader.readByType<double>() ) );
                break;

            case taf::DataHead::eString1:
            {
                size_t len = tReader.readByType<taf::UInt8>();
                char ss[256];
                tReader.readBuf( ss, len );
                ret.assign( ss, ss + len );
            }
            break;

            case taf::DataHead::eString4:
            {
                uint32_t len = ntohl( tReader.readByType<uint32_t>() );

                if( len > JCE_MAX_STRING_LENGTH )
                {
                    char s[128];
                    snprintf( s, sizeof( s ), "invalid string size,  size: %d", len );
                    throw JceDecodeInvalidValue( s );
                }

                char *ss = new char[len];

                try
                {
                    tReader.readBuf( ss, len );
                    ret.assign( ss, ss + len );
                }
                catch( ... )
                {
                    delete[] ss;
                    throw;
                }

                delete[] ss;
            }
            break;

            case taf::DataHead::eMap:
            {
                ret = "{";
                UInt32 size;
                tReader.read( size, 0 );

                if( size > tReader.size() )
                {
                    char s[128];
                    snprintf( s, sizeof( s ), "invalid map,  size: %d", size );
                    throw taf::JceDecodeInvalidValue( s );
                }

                for( UInt32 i = 0; i < size; ++i )
                {
                    string temp;
                    ret += "(";

                    if( JceReadRawData( tReader, temp ) )
                    {
                        ret += temp;
                    }

                    ret += ",";

                    if( JceReadRawData( tReader, temp ) )
                    {
                        ret += temp;
                    }

                    ret += ")";
                }

                ret += "}";
            }
            break;

            case DataHead::eList:
            {
                taf::UInt32 size;
                tReader.read( size, 0 );

                if( size > tReader.size() )
                {
                    char s[128];
                    snprintf( s, sizeof( s ), "invalid list,  size: %d", size );
                    throw JceDecodeInvalidValue( s );
                }

                ret = std::to_string( size ) + "{";

                for( taf::UInt32 i = 0; i < size; ++i )
                {
                    string temp;

                    if( JceReadRawData( tReader, temp ) )
                    {
                        ret += temp;
                    }
                }

                ret += "}";
            }
            break;

            case DataHead::eSimpleList:
            {
                taf::DataHead hh;
                hh.readFrom( tReader );

                if( hh.getType() != DataHead::eChar )
                {
                    char s[128];
                    snprintf( s, sizeof( s ), "type mismatch,  type: %d, %d", h.getType(), hh.getType() );
                    throw taf::JceDecodeMismatch( s );
                }

                taf::UInt32 size;
                tReader.read( size, 0 );

                if( size > tReader.size() )
                {
                    char s[128];
                    snprintf( s, sizeof( s ), "invalid simplelist,  size: %d", size );
                    throw JceDecodeInvalidValue( s );
                }

                vector<char> v;
                v.resize( size );
                tReader.readBuf( &v[0], size );
                ret = std::to_string( size ) + "{";

                if( !v.empty() )
                {
                    ret += std::to_string( ( int )v.front() );

                    for( vector<char>::iterator it = v.begin() + 1; it != v.end(); ++it )
                    {
                        ret += "|";
                        ret += std::to_string( ( int ) * it );
                    }
                }

                ret += "}";
            }
            break;

            case taf::DataHead::eStructBegin:
            {
                ret = "{";
                string temp;

                if( JceReadRawData( tReader, temp ) )
                {
                    ret += temp;

                    while( JceReadRawData( tReader, temp ) )
                    {
                        ret += "|" + temp;
                    }
                }

                ret += "}";
            }
            break;

            case taf::DataHead::eStructEnd:
                return false;

            default:
                break;
            }

            return true;
        }
        inline std::string JceBufferToStringImp( taf::JceInputStream<taf::BufferReader> &tReader )
        {
            string s, t;

            if( !tReader.hasEnd() )
            {
                JceReadRawData( tReader, t );
                s += t;

                while( !tReader.hasEnd() )
                {
                    s += "|";
                    JceReadRawData( tReader, t );
                    s += t;
                }
            }

            return s;
        }
    }
    template <typename T>
    inline typename std::enable_if<std::is_base_of<taf::JceStructBase, T>::value, JceSerializeImp::JceToVectorOrString<T> >::type Serialize( const T &t )
    {
        taf::JceOutputStream<taf::BufferWriter> os;
        t.writeTo( os );
        JceSerializeImp::JceToVectorOrString<T> vors( os );
        return vors;
    }
    template <typename T>
    inline typename std::enable_if < !std::is_base_of<taf::JceStructBase, T>::value &&isJceSerializable<T>::value, JceSerializeImp::JceToVectorOrString<T> >::type Serialize( const T &t )
    {
        taf::JceOutputStream<taf::BufferWriter> os;
        os.write( t, 0 );
        JceSerializeImp::JceToVectorOrString<T> vors( os );
        return vors;
    }

    template<typename T>
    inline typename std::enable_if<std::is_base_of<taf::JceStructBase, T>::value, T>::type Deserialize( taf::JceInputStream<taf::BufferReader> &is )
    {
        T t;
        t.readFrom( is );
        return t;
    }
    template<typename T>
    inline typename std::enable_if < !std::is_base_of<taf::JceStructBase, T>::value, T >::type Deserialize( taf::JceInputStream<taf::BufferReader> &is )
    {
        T t;
        is.read( t, 0 , false );
        return t;
    }

    template <typename T>
    inline T Deserialize( const std::vector<taf::Char> &vec )
    {
        taf::JceInputStream<taf::BufferReader> is;
        is.setBuffer( vec.data(), vec.size() );
        return Deserialize<T>( is );
    }

    template <typename T>
    inline T Deserialize( const std::string &vec )
    {
        taf::JceInputStream<taf::BufferReader> is;
        is.setBuffer( vec.data(), vec.size() );
        return Deserialize<T>( is );
    }

    inline std::string JceBufferToString( const std::string &vec )
    {
        taf::JceInputStream<taf::BufferReader> tReader;
        tReader.setBuffer( vec.data(), vec.size() );
        return JceSerializeImp::JceBufferToStringImp( tReader );
    }

    inline std::string JceBufferToString( const vector<taf::Char> &vec )
    {
        taf::JceInputStream<taf::BufferReader> tReader;
        tReader.setBuffer( vec.data(), vec.size() );
        return JceSerializeImp::JceBufferToStringImp( tReader );
    }
}
#ifndef DO_NOT_USING_JCESERIALIZE
using namespace JceSerialize;
#endif

#endif
