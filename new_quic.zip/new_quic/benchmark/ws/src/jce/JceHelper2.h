#ifndef __ACTJCEHELPER_H__
#define __ACTJCEHELPER_H__

#include <string>
#include "jce/Jce.h"

namespace JceSerialize
{
    template <typename T>
    inline T Deserialize(const std::string &vec)
    {
        taf::JceInputStream<taf::BufferReader> is;
        is.setBuffer( vec.data(), vec.size() );
        T t;
        t.readFrom( is );
        return t;
    }

    template <typename T>
    inline T Deserialize(const char* data, size_t ssize)
    {
        taf::JceInputStream<taf::BufferReader> is;
        is.setBuffer(data, ssize);
        T t;
        t.readFrom(is);
        return t;
    }

    template <typename T>
    inline T Deserialize(const std::vector<taf::Char>& vec)
    {
        taf::JceInputStream<taf::BufferReader> is;
        is.setBuffer(vec.data(), vec.data() + vec.size());
        T t;
        t.readFrom(is);
        return t;
    }

    template <typename T>
    inline std::string SerializeS(const T& t)
    {
        taf::JceOutputStream<taf::BufferWriter> os;
        t.writeTo( os );
        return std::string(os.getBuffer(), os.getLength() );
    }

    template <typename T>
    inline std::vector<taf::Char>&& Serialize(const T& t)
    {
        taf::JceOutputStream<taf::BufferWriter> os;
        t.writeTo( os );
        return std::vector<taf::Char>{ os.getBuffer(), os.getBuffer() + os.getLength() };
    }
}
#ifndef DO_NOT_USING_JCESERIALIZE
//using namespace JceSerialize;
#endif

#endif
