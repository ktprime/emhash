#include <atomic>
#include <thread>
#include <algorithm>

#ifndef _WIN32
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#elif USE_CERT
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "Shlwapi.lib")
#pragma comment(lib, "Dbghelp.lib")
#pragma comment(lib, "Version.lib")
#pragma comment(lib, "wbemuuid.lib")
#pragma comment(lib, "delayimp.lib")
#else
#include <WinSock2.h>
#pragma comment(lib, "WS2_32.lib")
#pragma comment(lib, "protobuf.lib")
#endif

#if QUIC_LINK
#include "QuicSpdyClientSessionWrapped.h"
#include "QuicSpdyHandler.h"
#endif

#include "qconfig.h"
#include "io_service.h"
//#include "qclock.h"
#include "util/tscns.h"

using namespace quic_sdk;
using namespace quic_sdk::simple;

/*
// ./out/Default/quic_server --quic_response_cache_dir=/tmp/quic-data/www.example.org   --quic_version=Q050 --certificate_file=/mnt/e/quic_new/benchmark/server/huya.crt  --key_file=/mnt/e/quic_new/benchmark/server/huya.pkcs8 --v=1
// ./out / Default / quic_client --host = 127.0.0.1 - v --port = 6121 v.huya.com / --quic_version = Q049
//typedef std::chrono::high_resolution_qclock.high_resolution_clock;
//typedef std::chrono::milliseconds milliseconds;
*/

static uint64_t g_tps{0}, g_rbytes{0}, g_sbytes{0};
static int grsp_size  = 4 << 10;
static int greq_size  = grsp_size >> 5;
static int g_stream   = 1;
static int g_pipeline = 512 * 1024 / (grsp_size * g_stream);

static uint64_t g_close= 0;
static int rand_close  = 0;
static int rand_send   = 0;
static bool use_ws     = true;
static bool use_1rrt   = true;
static int g_connection = 1;
static int g_allconns   = 1;

static std::string http_ws_head =
"GET / websocket HTTP / 1.1\r\nConnection: Upgrade\r\nHost: cdnws.api.huya.com : 443\r\nSec-WebSocket-Extensions: server_no_context_takeover; client_no_context_takeover\r\nSec-WebSocket-Key: 1nfFhaAuXEQ1ukqhiLDNZA == \r\nSec-WebSocket-Version: 13\r\nUpgrade: websocket\r\nUser-Agent: hysignal\r\n\r\n";

struct common_head
{
    int32_t id;
    int32_t pack;
    int64_t ss; //server send time
    int64_t cs; //client send time
    int64_t size = 0;
};
constexpr int common_head_size = sizeof(common_head) - 8;

inline static int64_t Now2us()
{
#if 0
    return QuicClockImpl::getInstance().NowMicroseconds();
#elif (__linux__ || __APPLE__ || __unix__)
    struct timeval start;
    gettimeofday(&start, NULL);
    return start.tv_sec * 1000000l + start.tv_usec;
#elif _WIN32
    FILETIME    file_time;
    SYSTEMTIME  system_time;
    ULARGE_INTEGER ularge;

    GetSystemTime(&system_time);
    SystemTimeToFileTime(&system_time, &file_time);
    ularge.LowPart  = file_time.dwLowDateTime;
    ularge.HighPart = file_time.dwHighDateTime;
    return ularge.QuadPart / 10 + system_time.wMilliseconds / 1000;
#elif _WIN64
    return GetTickCount64();
#else
    return clock();
#endif
}

class ClientConnection : public Connection
{
    using Connection::Connection;
    ehmap<int, common_head> stream_head_;
    char send_buffer_[1024 * 128];
    int send_offset_ = 0;
    int packetIdx_ = 0;
    int hand_state_ = 0;
    uint64_t hand_time_ = Now2us();

public:

    void sendConnectData(int stream = LastStream)
    {
        if (rand() % 10000 < rand_send)
            return ;

        std::string g_buf(greq_size, '\0');
        common_head head;
        head.pack = (greq_size << 16) + grsp_size;
        //assert(grsp_size % greq_size == 0);
        assert(greq_size < 65536 && grsp_size < 65536);

        const auto nowus = Now2us();
        head.cs = nowus;
        head.ss = nowus;

        for (int i = 0; i < g_stream; i++) {
            //recv time
            if (g_stream > 1)
                stream = CreateOutgoingStream()->StreamId();

            for (int j = 0; j < g_pipeline; ++j) {
                head.id = j;
                memcpy((char*)g_buf.data(), &head, common_head_size);
                Write(g_buf.c_str(), g_buf.size(), stream);
            }
        }
    }

    // only called by client peer.
    void OnConnected(QuicStream stream) override {
        //printf(" C[%d] quic connect time = %04lu ms\n", ++g_connection, (Now2us() - hand_time_) / 1000);
        if (hand_state_ == 0)
            hand_state_ = 1;

        if (!use_ws) {
            sendConnectData(stream);
        }
        else if (!use_1rrt) {
            Write(http_ws_head.c_str(), http_ws_head.size(), stream);
        }
    }

    const char* doWsRsp(const char* data, size_t& len, int stream)
    {
        const auto tail = strstr(data, "\r\n\r\n");
        if (strstr(data, "Upgrade") != nullptr && strstr(data, "websocket") != nullptr && tail != nullptr) {
            hand_state_ = 2;
            sendConnectData(stream);
            printf(" ws[%d] = %04d ms\n", ++g_connection, int(Now2us() - hand_time_) / 1000);
            len -= (tail - data) + 4;
            if (0 == len)
                return nullptr;
             return tail + 4;
        }
        return data;
    }

    void OnRecv(const char* data, size_t len, QuicStream stream) override {
        g_tps ++;
        g_rbytes += len;

        if (hand_state_ != 2 && use_ws) {
            data = doWsRsp(data, len, stream);
            if (!data)
                return;
        }

        int offset  = 0;
        auto& head  = stream_head_[stream];
        auto& hsize = head.size;
        if (hsize != 0) {
            const auto total = hsize + len;
            if (total < grsp_size) {
                if (hsize < common_head_size)
                    memcpy((char*)&head + hsize, data, common_head_size - hsize);
                hsize = total;
                return;
            } else if (hsize < common_head_size) {
                memcpy((char*)&head + hsize, data, common_head_size - hsize);
            }

            offset = grsp_size - hsize;

            //head.cs = Now2us();
            memcpy(send_buffer_ + send_offset_, &head, common_head_size);
            send_offset_ += greq_size;
            if (stream_head_.size() == 1 && g_stream == 1)
                assert(head.id == packetIdx_);
            assert((unsigned)head.pack == (unsigned)(greq_size << 16) + grsp_size);
            packetIdx_ = (packetIdx_ + 1) % g_pipeline;
        }

        const auto nowus = Now2us();
        auto nreq = (char*)send_buffer_ + send_offset_;
        while (offset + grsp_size <= (int)len) {
            packetIdx_ ++;
            memcpy(nreq, data + offset, common_head_size);
            //auto& head = *(common_head*)(nreq);
            //assert(head.id == packetIdx_ || g_stream == 1);
            //head.cs = nowus;//update client time ss

            offset += grsp_size;
            nreq   += greq_size;
            send_offset_ += greq_size;
            if (send_offset_ > sizeof(send_buffer_) * 3 / 4 + 8000) {
                FlushBuffer(stream, 0);
            }
        }
        packetIdx_ %= g_pipeline;

        //packe last
        int remain = len - offset;
        if (remain > 0)
            memcpy(&head, data + offset, std::min(common_head_size, remain));
        hsize = remain;

//        if (send_offset_ > sizeof(send_buffer_) * 3 / 4 + 8000) {
//            FlushBuffer(stream, 0);
//        }

        if (rand_close && g_close == 0 && ((g_tps & rand_close) == 0))
            g_close = Socket();
    }

    void FlushBuffer(int stream, int res) override {
        if (send_offset_ > 0) {
            Write(send_buffer_, send_offset_, stream);
            g_sbytes += send_offset_;
            send_offset_ = 0;
        }
        g_tps -= res;
    }

    void OnClose(int quicError, bool bFromRemote) override {
        //printf("Close Socket fd = %d quicErr=%d, closeByPeer:%d\n", Socket(), quicError, bFromRemote);
        if (hand_state_ == 2)
            g_connection --;

        if (g_close == Socket())
            g_close = 0;
        delete this;
    }

    void OnStreamClose(int quicError, QuicStream stream) override {
        stream_head_.erase(stream);
    }
};

//const std::string&, const char*, int, const char*, const char*
static void log_func(const char* cfile, int line, const char* func, const char* slog)
{
    printf("%s %s:%d %s\n", cfile, func, line, slog);
}

static const auto show_delay = 4;
static void show(double delay) {
    static int64_t last_tps = 0, last_rbytes = 0,last_sbytes = 0;
    int64_t tps    = g_tps    - last_tps;
    int64_t rbytes = g_rbytes - last_rbytes;
    int64_t sbytes = g_sbytes - last_sbytes;

    //if (rbytes > 0) {
        double MBS =  (1024 * 1024 * delay);
        printf("-----------------------------------------------------------------------TPS: %5d/sec, QPS: %6d/sec, RBW %3.2lf, SBW: %3.2f MB/sec Cons:%2d\n",
                int(tps / delay), (int)(rbytes / (grsp_size * delay)), rbytes / MBS, sbytes / MBS, (int)g_connection);
    //}

    last_tps = g_tps;
    last_rbytes = g_rbytes;
    last_sbytes = g_sbytes;
}

static void startThread(struct sockaddr_in* addr, const int conns, const std::string& oneRttData)
{
    std::thread work([=]()
    {
        IOService ios(true);
        for (int i = 0; i < conns; ++i) {
            ClientConnection* c = new ClientConnection(&ios);
            c->Connect((struct sockaddr*)addr, sizeof(sockaddr_in), oneRttData);
        }
        printf("=================== thread server:port:%s:%d ep = %d\n\n", inet_ntoa(addr->sin_addr), (int)htons(addr->sin_port), ios.epFd());

        auto socket = 0;
        auto sock_adrr = *addr;
        auto nextcon = 0;
        for ( ;; ) {
            ios.Run(1000);

            //rand stop some connections
            auto socket = g_close;
            if (socket > 0) {
                std::thread closethread([&ios, socket] {
                    //QuicEpollCtl(ios.epFd(), EPOLL_CTL_DEL, socket, nullptr);
                    bool ret = ios.CloseConnect(g_close);
                    printf("    close ret = %d, socket = %d\n", (int)ret, (int)socket);
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                });
                g_close = 0;
                closethread.detach();
            }
            //retry connect
            if (conns > ios.GetConnSize() && nextcon < time(0)) {
                ClientConnection* c = new ClientConnection(&ios);
                c->Connect((struct sockaddr*)&sock_adrr, sizeof(sockaddr_in), oneRttData);
                nextcon = time(0) + 2;
            }
        }

        printf("=================== exit server:port:%s:%d ep = %d\n\n", inet_ntoa(addr->sin_addr), (int)htons(addr->sin_port), ios.epFd());
    });

    work.detach();
}

inline static uint64_t rdtsc() {
#if __linux__
#if defined(__aarch64__) || defined(__arm__)
        uint64_t cntvct;
        asm volatile ("isb; mrs %0, cntvct_el0; isb; " : "=r" (cntvct) :: "memory");
        return cntvct;
#else
#if 1
        uint32_t high, low;
        __asm__ __volatile__( "rdtsc" : "=a" (low), "=d" (high));
        return ((uint64_t)high << 32) | low;
#else
        return __builtin_ia32_rdtsc();
#endif
#endif
#else
        return __rdtsc();
#endif
}

static void timeTest(const int loop = 1e6)
{
    uint64_t sumt = 0;
    uint64_t nowus = Now2us();
#if 0
    for (int i = 0; i < loop; i++) {
        sumt += QuicClockImpl::getInstance().NowMicroseconds();
    }
    printf("loops timeTest %d\nNow2us %ld ms[%ld ns], sumt = %ld\n", loop, (Now2us() - nowus) / 1000, (Now2us() - nowus) / (loop / 1000), sumt);
#endif

#if __linux__ && __X86_64__
    sumt = 0;
    nowus = Now2us();
    for (int i = 0; i < loop; i++) {
        sumt += __builtin_ia32_rdtsc();
    }
    printf("__builtin_ia32_rdtsc %ld ms, sumt = %ld\n",(Now2us() - nowus) / 1000, sumt);
#endif

    sumt = 0;
    nowus = Now2us();
    for (int i = 0; i < loop; i++) {
        sumt += rdtsc();
    }
    printf("rdtsc %ld ms, sumt = %ld\n",(Now2us() - nowus) / 1000, sumt);

    sumt = 0;
    nowus = Now2us();
    for (int i = 0; i < loop; i++) {
        auto tp = std::chrono::steady_clock::now();
        sumt += std::chrono::duration_cast<std::chrono::microseconds>(tp.time_since_epoch()).count();
    }
    printf("steady_clock %ld ms, sumt = %ld\n",(Now2us() - nowus) / 1000, sumt);

    TSCNS tn;
    double cpu_freq = tn.init();
    nowus = Now2us();
    for (int i = 0; i < loop; i++) {
        sumt += tn.rdns();
    }
    printf("rdns %ld ms, sumt = %ld: freq = %.3lf\n",(Now2us() - nowus) / 1000, sumt, cpu_freq);

    puts("-------------------\n\n");
}

#if QUIC_LINK
void testHandle(struct sockaddr_in addr)
{
     auto ptr = new quic::QuicSpdyHandler;
     auto ret = ptr->Connect(*(int*)&addr.sin_addr, htons(addr.sin_port), "v.huya.com", 10);

     printf("ret = %d\n", ret);
}
#endif

int main(int argc, char* argv[])
{
#ifdef _WIN32
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif

    //f q43 p443 i47.246.10.243 w
    puts("example: ./bclient2 i127.0.0.1 p443 d14 l2 y2 q43 g100 c10 s4 n t2 f w r1 u128 v4096 o(share) x(rand send)\n");
    ehmap<char, const char*> help = {
        {'i', "server ip[0,3,4] 127.0.0.1"},
        {'p', "server port 443"},
        {'c', "connections 1"},
        {'t', "threads 1"},

        {'g', "send online packet 512[KM]"},
        {'s', "streams 1"},
        {'b', "max packet size 1450"},

        {'d', "debug info -1-31"},
        {'y', "set bbr 1-2"},
        {'n', "set cert 0"},
        {'a', "auto close test 0"},
        {'q', "quic version 43"},
        {'f', "use server config 0"},
        {'w', "websocket hand 1"},
        {'r', "set 1-rtt 1"},
        {'l', "server listen size 1"},
        {'u', "req packet size 24-64k"},
        {'v', "rsp packet size 24-64k"},
        {'o', "client share udp 1-1000"},
        {'x', "rand send 0-10000"},
    };

    for (auto&cmd : help) {
        printf("    %c %s\n", cmd.first, cmd.second);
    }

    srand(time(0));
    uint64_t debug_mask = dbg_error | dbg_warn;
    QuicSetLogFunc(log_func, debug_mask);

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(6121);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    int back_cfd = -1;
    int listen = 0, quic_version = 43, threads = 0;

    for (int i = 1; i < argc; i++)
    {
        const auto cmd = argv[i][0];
        const char* arg = argv[i] + 1;
        const int avi = atoi(arg);

        if (cmd == 'i') {
            if (arg[0] == '0') {
                arg = "112.90.94.153"; addr.sin_port = htons(443);
            }
            else if (arg[0] == '3' && strchr(arg, '.') == NULL) {
                arg = "120.76.62.74"; addr.sin_port = htons(443);
            }
            else if (arg[0] == '4' && strchr(arg, '.') == NULL) {
                arg = "44.225.134.56"; addr.sin_port = htons(443);//us
            }
            else if (arg[0] == '5' && strchr(arg, '.') == NULL) {
                arg = "18.138.152.98"; addr.sin_port = htons(6121);//sig
            }
            addr.sin_addr.s_addr = inet_addr(arg);
        }
        else if (cmd == 'p') {
            addr.sin_port = htons(avi);
        }
        else if (cmd == 'c') {
            g_connection = g_allconns = avi;
        }
        else if (cmd == 's') {
            g_stream = avi;
            assert(g_stream > 0 && g_stream < 1000);
        }
        else if (cmd == 'd') {
            int mask = avi;
            if (mask == 0)
                debug_mask = 0;
            else if (mask < 0)
                debug_mask = -1u;
            else if (mask < 30)
                debug_mask |= (1ul << mask);
            else
                debug_mask |= mask;
            QuicSetLogFunc(log_func, debug_mask);
        }
        else if (cmd == 'g')
            g_pipeline = avi;
        else if (cmd == 'l')
            listen = 1 - listen;
        else if (cmd == 't')
            threads = avi;
        else if (cmd == 'q')
            quic_version = avi;
        else if (cmd == 'a')
            rand_close = (1ull << avi) - 1;
        else if (cmd == 'u') {
            greq_size = avi;
            if (strchr(arg, 'k') != nullptr)
                greq_size *= 1024;
            if (greq_size < common_head_size)
                greq_size = 1 << greq_size;
        }
        else if (cmd == 'v') {
            grsp_size = avi;
            if (strchr(arg, 'k') != nullptr)
                grsp_size *= 1024;
            if (grsp_size < common_head_size)
                grsp_size = 1 << grsp_size;
        }
        else if (cmd == 'x')
            rand_send = avi;
        else if (cmd == 'w')
            use_ws = !use_ws;
        else if (cmd == 'r')
            use_1rrt = !use_1rrt;
        else if (cmd == 'f') {
            QuicSetOption("scfg", 1);
        }
        else if (cmd == 'o') {
            QuicSetOption("share_socket", avi);
        }
        else if (cmd == 'n')
            QuicSetOption("back_udp", back_cfd = avi);
        else if (cmd == 'z')
            QuicSetOption("hyc", avi);
        else if (cmd == 'b')
            QuicSetOption("packet", avi);
        else if (cmd == 'y') {
            QuicSetBBR(avi);
            QuicSetOption("bbr", avi);
        }
    }

    struct sockaddr_in addr2; addr2.sin_family = AF_INET;
    memcpy(&addr2, &addr, sizeof(addr));
    addr2.sin_port = addr.sin_port + (1 << 8);

    printf("connect to server %s:%d, connection = %d, streams = %d, packet_size = %d\n debug = %d\n(use_config, back_cfd, bbr, qversion, ws:1rtt) = (%d,%d,%d, Q0%d, %d:%d), BW*RTT = %dK\n",
            inet_ntoa(addr.sin_addr), (int)htons(addr.sin_port), g_connection, g_stream, grsp_size, (int)debug_mask,
        QuicHasOption("scfg"), (int)back_cfd, QuicHasOption("bbr"),
            quic_version, (int)use_ws, (int)use_1rrt, (int)(grsp_size * g_stream * ((int)g_connection) * g_pipeline)/1024);

    //initQuic(use_text, false, use_bbr, use_config, quic_version);
    QuicSetOption("chrome_quic_log", 0);
    timeTest();

    assert(g_pipeline >= 2);
    assert(grsp_size >= common_head_size && grsp_size < 64*1024);
    assert(greq_size >= common_head_size && greq_size < 64*1024);

    IOService ios(true);
    auto ileft = 0;
    const std::string& oneRttData = (use_1rrt && use_ws) ? http_ws_head : "";
    for (int i = 0; i < (int)g_connection; ++i) {
        ClientConnection* c = new ClientConnection(&ios);
        c->Connect((struct sockaddr*)&addr, sizeof(addr), oneRttData);
        if (listen)
            addr.sin_port = addr.sin_port + (1 << 8);

        if (i >= 10) {
            ileft = g_connection - i - 1;
            break;
        }
        ios.Run(1);
    }

    if (listen)
        addr.sin_port -= (1 << 8) * (g_connection - 1);

    auto last_show = Now2us();
    auto nextcon = time(0) + 10;

    const int conns = g_connection;
    g_connection = 0;
    for (int i = 1; i < threads; i++)
    {
        printf("=================== start thread %d\n", i + 1);
        if (listen == 0)
            startThread(&addr, conns, oneRttData);
        else {
            addr2.sin_port = addr.sin_port + (1 << 8) * i;
            startThread(&addr2, conns, oneRttData);
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    for (;;) {
        if (ios.Run(1000) < 0) {
            puts("wait error");
            break;
        }
//        else if (rand() % 100 == 0)
//            break;

        const auto nowus = Now2us();
        const auto delay = (nowus - last_show) / 1000000.0;
        if (delay > show_delay) {
            show(delay);
            last_show = nowus;
        }

#if 1
        auto nows = time(0);
        //start the left connections
        for (; ileft > 0 && time(0) > nextcon; ) {
            ClientConnection* c = new ClientConnection(&ios);
            c->Connect((struct sockaddr*)&addr, sizeof(addr), oneRttData);
            ios.Run(1);
            if (ileft-- && rand() % 512 == 0) {
                nextcon = time(0) + 2;
                break;
            }
        }
        if (g_close > 0 && nows > nextcon) {
            //rand stop some connections
            auto socket = g_close;
            if (socket > 0) {
                std::thread closethread([socket] {
                    bool ret = QuicAsynCloseSocket(socket, "AsynClose2") == 0;
                    printf("    close ret = %d, socket = %d\n", (int)ret, (int)socket);
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                    g_close = 0;
                });

                closethread.detach();
            }
            nextcon = nows + 2;
        }
        if (ileft == 0 && g_allconns > g_connection && nows > nextcon) {
            ClientConnection* c = new ClientConnection(&ios);
            if (rand() % 2 >= listen) {
                c->Connect((struct sockaddr*)&addr, sizeof(addr), oneRttData);
            }
            else {
                c->Connect((struct sockaddr*)&addr2, sizeof(addr2), oneRttData);
            }
            nextcon = nows + 2;
        }
#endif
    }

    return 0;
}
